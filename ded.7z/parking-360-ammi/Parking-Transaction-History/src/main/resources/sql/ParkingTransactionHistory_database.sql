
CREATE TABLE parkingtransaction.parkingtransactions
(
    parking_transaction_token integer NOT NULL,
    ciamid character varying(100) COLLATE pg_catalog."default" NOT NULL,
    licence_plate character varying(100) COLLATE pg_catalog."default" NOT NULL,
    parking_duration double precision,
    parking_cost double precision,
    service_provider character varying(50) COLLATE pg_catalog."default",
    payment_transaction_number character varying(100) COLLATE pg_catalog."default",
    notification_number character varying(100) COLLATE pg_catalog."default",
    active character varying(50) COLLATE pg_catalog."default",
    status character varying(100) COLLATE pg_catalog."default",
    booking_id character varying(100) COLLATE pg_catalog."default",
    creation_time date,
    updation_time date,
    CONSTRAINT "ParkingTransactions_pkey" PRIMARY KEY (parking_transaction_token)
)
WITH (
    OIDS = FALSE
)


----------------------------------------------------------------------------------------------------
CREATE TABLE parkingtransaction.barrierinfo
(
    barrierinfo_id integer NOT NULL,
    type character varying(100) COLLATE pg_catalog."default",
    open_barrier_id character varying(200) COLLATE pg_catalog."default",
    closing_barrier_id character varying(200) COLLATE pg_catalog."default",
    open_barrier_count bigint,
    close_barrier_count bigint,
    parking_transaction_token integer NOT NULL,
    CONSTRAINT barrierinfo_id PRIMARY KEY (barrierinfo_id),
    CONSTRAINT parking_transaction_token FOREIGN KEY (parking_transaction_token)
        REFERENCES parkingtransaction.parkingtransactions (parking_transaction_token) MATCH SIMPLE
        ON UPDATE NO ACTION
        ON DELETE NO ACTION
)
WITH (
    OIDS = FALSE
)
----------------------------------------------------------------------------------------------------
CREATE TABLE parkingtransaction.parkingspace
(
    parking_space_id integer NOT NULL,
    latitude double precision,
    longitude double precision,
    access_method character varying(100) COLLATE pg_catalog."default",
    description character varying(500) COLLATE pg_catalog."default",
    type character varying(100) COLLATE pg_catalog."default",
    image_url character varying(200) COLLATE pg_catalog."default",
    feature character varying(100) COLLATE pg_catalog."default",
    parking_transaction_token integer,
    start_time character varying(50) COLLATE pg_catalog."default",
    end_time character varying(50) COLLATE pg_catalog."default",
    CONSTRAINT "ParkingSpace_pkey" PRIMARY KEY (parking_space_id),
    CONSTRAINT "parking_transaction_token_FK" FOREIGN KEY (parking_transaction_token)
        REFERENCES parkingtransaction.parkingtransactions (parking_transaction_token) MATCH SIMPLE
        ON UPDATE CASCADE
        ON DELETE CASCADE
)
WITH (
    OIDS = FALSE
)