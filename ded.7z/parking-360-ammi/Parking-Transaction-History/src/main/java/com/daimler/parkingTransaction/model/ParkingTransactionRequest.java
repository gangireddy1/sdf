package com.daimler.parkingTransaction.model;

import java.io.Serializable;

import org.hibernate.validator.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class ParkingTransactionRequest extends BaseRequest implements Serializable{
	
	private static final long serialVersionUID = 611838699138105348L;
	
	@ApiModelProperty(value = "bookingDetails", readOnly = true)
	@JsonProperty("bookingDetails")
	
	private BookingDetails bookingDetails;
	
	@ApiModelProperty(value = "notificationId", readOnly = true)
	@JsonProperty("notificationId")
	
	private String notificationId;
	
	@ApiModelProperty(value = "txnID", readOnly = true)
	@JsonProperty("txnID")
	private String txnID;
	
	@ApiModelProperty(value = "serviceProvider", readOnly = true)
	@JsonProperty("serviceProvider")
	private String serviceProvider;
	
	private String cancelledAt;

	public BookingDetails getBookingDetails() {
		return bookingDetails;
	}

	public void setBookingDetails(BookingDetails bookingDetails) {
		this.bookingDetails = bookingDetails;
	}

	public String getTxnID() {
		return txnID;
	}

	public void setTxnID(String txnID) {
		this.txnID = txnID;
	}

	public String getCancelledAt() {
		return cancelledAt;
	}

	public void setCancelledAt(String cancelledAt) {
		this.cancelledAt = cancelledAt;
	}

	public String getNotificationId() {
		return notificationId;
	}

	public void setNotificationId(String notificationId) {
		this.notificationId = notificationId;
	}

	public String getServiceProvider() {
		return serviceProvider;
	}

	public void setServiceProvider(String serviceProvider) {
		this.serviceProvider = serviceProvider;
	}
	
}
