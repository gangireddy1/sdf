/**
 * Copyright 2017 Mercedes Benz Research & Development, A Daimler Company. All rights reserved.
 */

package com.daimler.parkingTransaction.service;

import java.io.FileInputStream;
import java.security.KeyStore;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * @author avasuku
 *
 */

@Component
public class DataEncryptionDecryptionService {
    // ****************************************************************************************************************
    // ******************************************** Public Fields *****************************************************
    // ****************************************************************************************************************

    private static final Logger logger = LoggerFactory.getLogger(DataEncryptionDecryptionService.class);
    
    static Cipher cipher;

    // ****************************************************************************************************************
    // ****************************************** Non Public Fields ***************************************************
    // ****************************************************************************************************************

    // ****************************************************************************************************************
    // ******************************************** Public Methods ****************************************************
    // ****************************************************************************************************************

    // ****************************************************************************************************************
    // ****************************************** Non Public Methods **************************************************
    // ****************************************************************************************************************

    public static  SecretKey loadKey() throws Exception {

        KeyStore ks = KeyStore.getInstance( "JCEKS" );

        FileInputStream fis = null;
        SecretKey key = null;
       
        try {
            
            //fis = new FileInputStream( "/home/ammiserver/AMMI/config/aes-keystore.jck" );
            fis = new FileInputStream( "c:/aes-keystore.jck" );
            ks.load( fis, "amm!@ampido".toCharArray() );

            logger.info( "KeyStore loaded...." + ks.getProvider() );

            KeyStore.ProtectionParameter protParam = new KeyStore.PasswordProtection( "amm!@ampido".toCharArray() );
            KeyStore.SecretKeyEntry secretKeyEntry = (KeyStore.SecretKeyEntry) ks.getEntry( "jceksaes", protParam );

            key = secretKeyEntry.getSecretKey();

          
        } catch ( Exception e ) {
            logger.info( "Error opening keyfile:" + e.getMessage() );
            throw e;
        } finally {
            if(null != fis) {
            fis.close();
            }
        }

        
        logger.info("Key =="+ key.getAlgorithm() );
        
        return key;

    }

    public String encryptText(String plainText) throws Exception {

        SecretKey secretKey = loadKey();
        byte[] plainTextByte = plainText.getBytes();
        
        cipher = Cipher.getInstance("AES");
        
        cipher.init( Cipher.ENCRYPT_MODE, secretKey );
        byte[] encryptedByte = cipher.doFinal( plainTextByte );
        Base64.Encoder encoder = Base64.getEncoder();
        String encryptedText = encoder.encodeToString( encryptedByte );
        return encryptedText;
    }

    public static String decryptText(String encryptedText) throws Exception {

        SecretKey secretKey = loadKey();
        cipher = Cipher.getInstance("AES");
        
        Base64.Decoder decoder = Base64.getDecoder();
        byte[] encryptedTextByte = decoder.decode( encryptedText );
        cipher.init( Cipher.DECRYPT_MODE, secretKey );
        byte[] decryptedByte = cipher.doFinal( encryptedTextByte );
        String decryptedText = new String( decryptedByte );
        return decryptedText;
    }

}
