package com.daimler.parkingTransaction.exceptions;

public class AuthorizationException extends RuntimeException {
    public AuthorizationException() {
        super();
    }

}
