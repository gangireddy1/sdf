package com.daimler.parkingTransaction.db.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the parkingspace database table.
 * 
 */
@Entity
@Table(name = "parkingspace", schema = "parkingtransaction")
public class Parkingspace implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "parking_space_id", unique = true, nullable = false)
    private Integer parkingSpaceId;

    @Column(name = "access_method", length = 20)
    private String accessMethod;

    @Column(length = 50)
    private String description;

    //@Temporal(TemporalType.TIMESTAMP)
    @Column(name = "end_time")
    private String endTime;

    @Column(length = 50)
    private String feature;

    @Column(name = "image_url", length = 70)
    private String imageUrl;

    private double latitude;

    private double longitude;

    //@Temporal(TemporalType.TIMESTAMP)
    @Column(name = "start_time")
    private String startTime;

    @Column(length = 30)
    private String type;

    // bi-directional many-to-one association to Parkingtransaction
    @ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="parking_transaction_token", nullable=false)
    private Parkingtransaction parkingtransaction;

    public Parkingspace() {
    }

    public Integer getParkingSpaceId() {
        return this.parkingSpaceId;
    }

    public void setParkingSpaceId(Integer parkingSpaceId) {
        this.parkingSpaceId = parkingSpaceId;
    }

    public String getAccessMethod() {
        return this.accessMethod;
    }

    public void setAccessMethod(String accessMethod) {
        this.accessMethod = accessMethod;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFeature() {
        return this.feature;
    }

    public void setFeature(String feature) {
        this.feature = feature;
    }

    public String getImageUrl() {
        return this.imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public double getLatitude() {
        return this.latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return this.longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getType() {
        return this.type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Parkingtransaction getParkingtransaction() {
        return this.parkingtransaction;
    }

    public void setParkingtransaction(Parkingtransaction parkingtransaction) {
        this.parkingtransaction = parkingtransaction;
    }

    

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    @Override
    public String toString() {
        return "Parkingspace [parkingSpaceId=" + parkingSpaceId + ", accessMethod=" + accessMethod + ", description=" + description + ", endTime="
                + endTime + ", feature=" + feature + ", imageUrl=" + imageUrl + ", latitude=" + latitude + ", longitude=" + longitude + ", startTime="
                + startTime + ", type=" + type + ", parkingtransaction=" + parkingtransaction + "]";
    }

    
    
}