package com.daimler.parkingTransaction.model;

import java.io.Serializable;

public class ParkingBookingResponse extends BaseResponse implements Serializable{
	
	

}
