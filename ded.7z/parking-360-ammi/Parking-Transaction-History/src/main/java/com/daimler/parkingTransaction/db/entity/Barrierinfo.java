package com.daimler.parkingTransaction.db.entity;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the barrierinfo database table.
 * 
 */
@Entity
@Table(name = "barrierinfo", schema = "parkingtransaction")
public class Barrierinfo implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="barrierinfo_id", unique=true, nullable=false)
	private Integer barrierinfoId;

	@Column(name="close_barrier_count")
	private int closeBarrierCount;

	@Column(name="closing_barrier_id", length=70)
	private String closingBarrierId;

	@Column(name="open_barrier_count")
	private int openBarrierCount;

	@Column(name="open_barrier_id", length=70)
	private String openBarrierId;

	@Column(length=20)
	private String type;

	// bi-directional many-to-one association to ParkingTransaction
	@ManyToOne(cascade=CascadeType.ALL)
    @JoinColumn(name="parking_transaction_token", nullable=false)
    private Parkingtransaction parkingtransaction;

	public Barrierinfo() {
	}

	public Integer getBarrierinfoId() {
		return this.barrierinfoId;
	}

	public void setBarrierinfoId(Integer barrierinfoId) {
		this.barrierinfoId = barrierinfoId;
	}

	public void setCloseBarrierCount(int closeBarrierCount) {
		this.closeBarrierCount = closeBarrierCount;
	}

	public String getClosingBarrierId() {
		return this.closingBarrierId;
	}

	public void setClosingBarrierId(String closingBarrierId) {
		this.closingBarrierId = closingBarrierId;
	}

	public int getOpenBarrierCount() {
		return this.openBarrierCount;
	}

	public void setOpenBarrierCount(int openBarrierCount) {
		this.openBarrierCount = openBarrierCount;
	}

	public String getOpenBarrierId() {
		return this.openBarrierId;
	}

	public void setOpenBarrierId(String openBarrierId) {
		this.openBarrierId = openBarrierId;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Parkingtransaction getParkingtransaction() {
		return this.parkingtransaction;
	}

	public void setParkingtransaction(Parkingtransaction parkingtransaction) {
		this.parkingtransaction = parkingtransaction;
	}

	
	
	
}