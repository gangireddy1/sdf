package com.daimler.parkingTransaction.model;

public class BaseRequest {

}
