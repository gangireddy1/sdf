/**
 * Copyright 2017 Mercedes Benz Research & Development, A Daimler Company. All rights reserved.
 */

package com.daimler.parkingTransaction.model;

/**
 * @author avasuku
 *
 */
public class ParkingTransactionHistoryResponse {

	private String statusCode;
	private String statusText;

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

}
