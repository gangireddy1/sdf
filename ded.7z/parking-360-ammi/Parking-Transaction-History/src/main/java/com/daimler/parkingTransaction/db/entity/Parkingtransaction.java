package com.daimler.parkingTransaction.db.entity;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * The persistent class for the parkingtransactions database table.
 * 
 */
@Entity
@Table(name = "parkingtransactions", schema = "parkingtransaction")
public class Parkingtransaction implements Serializable {
    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "parking_transaction_token", unique = true, nullable = false)
    private Integer parkingTransactionToken;

    @Column(length = 10)
    private String active;

    @Column(name = "booking_id", length = 80)
    private String bookingId;

    @Column(nullable = false, length = 50)
    private String ciamid;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "creation_time")
    private Date creationTime;

    @Column(name = "licence_plate", nullable = false, length = 50)
    private String licencePlate;

    @Column(name = "notification_number", length = 30)
    private String notificationNumber;

    @Column(name = "parking_cost")
    private double parkingCost;

    @Column(name = "parking_duration")
    private double parkingDuration;

    @Column(name = "payment_transaction_number", length = 30)
    private String paymentTransactionNumber;

    @Column(name = "service_provider", length = 30)
    private String serviceProvider;

    @Column(length = 80)
    private String status;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updation_time")
    private Date updationTime;

    // bi-directional many-to-one association to BarrierInfo
    @OneToMany(mappedBy = "parkingtransaction", cascade = CascadeType.ALL)
    private List<Barrierinfo> barrierinfos;

    @OneToMany(mappedBy = "parkingtransaction", cascade = CascadeType.ALL)
    private List<Parkingspace> parkingspaces;

    public Parkingtransaction() {
    }

    public Integer getParkingTransactionToken() {
        return this.parkingTransactionToken;
    }

    public void setParkingTransactionToken(Integer parkingTransactionToken) {
        this.parkingTransactionToken = parkingTransactionToken;
    }

    public String getActive() {
        return this.active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getBookingId() {
        return this.bookingId;
    }

    public void setBookingId(String bookingId) {
        this.bookingId = bookingId;
    }

    public String getCiamid() {
        return this.ciamid;
    }

    public void setCiamid(String ciamid) {
        this.ciamid = ciamid;
    }

    public Date getCreationTime() {
        return creationTime;
    }

    public void setCreationTime(Date creationTime) {
        this.creationTime = creationTime;
    }

    public Date getUpdationTime() {
        return updationTime;
    }

    public void setUpdationTime(Date updationTime) {
        this.updationTime = updationTime;
    }

    public String getLicencePlate() {
        return this.licencePlate;
    }

    public void setLicencePlate(String licencePlate) {
        this.licencePlate = licencePlate;
    }

    public String getNotificationNumber() {
        return this.notificationNumber;
    }

    public void setNotificationNumber(String notificationNumber) {
        this.notificationNumber = notificationNumber;
    }

    public double getParkingCost() {
        return this.parkingCost;
    }

    public void setParkingCost(double parkingCost) {
        this.parkingCost = parkingCost;
    }

    public double getParkingDuration() {
        return this.parkingDuration;
    }

    public void setParkingDuration(double parkingDuration) {
        this.parkingDuration = parkingDuration;
    }

    public String getPaymentTransactionNumber() {
        return this.paymentTransactionNumber;
    }

    public void setPaymentTransactionNumber(String paymentTransactionNumber) {
        this.paymentTransactionNumber = paymentTransactionNumber;
    }

    public String getServiceProvider() {
        return this.serviceProvider;
    }

    public void setServiceProvider(String serviceProvider) {
        this.serviceProvider = serviceProvider;
    }

    public String getStatus() {
        return this.status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<Barrierinfo> getBarrierinfos() {
        return this.barrierinfos;
    }

    public void setBarrierinfos(List<Barrierinfo> barrierinfos) {
        this.barrierinfos = barrierinfos;
    }

    public Barrierinfo addBarrierinfo(Barrierinfo barrierinfo) {
        getBarrierinfos().add( barrierinfo );
        barrierinfo.setParkingtransaction( this );

        return barrierinfo;
    }

    public Barrierinfo removeBarrierinfo(Barrierinfo barrierinfo) {
        getBarrierinfos().remove( barrierinfo );
        barrierinfo.setParkingtransaction( null );

        return barrierinfo;
    }

    public List<Parkingspace> getParkingspaces() {
        return this.parkingspaces;
    }

    public void setParkingspaces(List<Parkingspace> parkingspaces) {
        this.parkingspaces = parkingspaces;
    }

    public Parkingspace addParkingspace(Parkingspace parkingspace) {
        getParkingspaces().add( parkingspace );
        parkingspace.setParkingtransaction( this );

        return parkingspace;
    }

    public Parkingspace removeParkingspace(Parkingspace parkingspace) {
        getParkingspaces().remove( parkingspace );
        parkingspace.setParkingtransaction( null );

        return parkingspace;
    }

}