package com.daimler.parkingTransaction.dao;

import com.daimler.parkingTransaction.db.entity.Parkingtransaction;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Component;

@Component
public interface ParkingTransactionRepository extends CrudRepository<Parkingtransaction, Long> {
	
	//public int addParkingTransaction(ParkingTransaction parkingTransaction);

	//public ParkingTransactionDetails updateParkingTransaction(BookingDetails BookingDetails);
	
	//public List<ParkingTransactionDetails> viewParkingTransactions();

	@Query("SELECT p FROM Parkingtransaction p WHERE p.ciamid = :ciamid")
	public List<Parkingtransaction> getParkingSpaceDetailsByCiamId(@Param("ciamid") String ciamid);
	//public ParkingTransactionDetails viewParkingTransactionsById(String Id);

}
