package com.daimler.parkingTransaction.model;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import io.swagger.annotations.ApiModelProperty;

public class BookingDetails extends BaseResponse implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@ApiModelProperty(value = "uuid", readOnly = true)
	@JsonProperty("uuid")
	@NotEmpty(message = "uuid cannot be blank.")
	private String uuid;
	
	@ApiModelProperty(value = "startTime", readOnly = true)
	@JsonProperty("startTime")
	@NotEmpty(message = "startTime cannot be blank.")
	private String startTime;
	
	@ApiModelProperty(value = "endTime", readOnly = true)
	@JsonProperty("endTime")
	@NotEmpty(message = "endTime cannot be blank.")
	private String endTime;
	
	@ApiModelProperty(value = "licenceplate", readOnly = true)
	@JsonProperty("licenceplate")
	@NotEmpty(message = "licenceplate cannot be blank.")
	private String licenceplate;
	
	@ApiModelProperty(value = "barriers", readOnly = true)
	@JsonProperty("barriers")
	@NotEmpty(message = "barriers cannot be blank.")
	private List<Barrier> barriers;
	
	@ApiModelProperty(value = "parkingSlot", readOnly = true)
	@JsonProperty("parkingSlot")
	@NotEmpty(message = "parkingSlot cannot be blank.")
	private ParkingSlot parkingSlot;
	
	@ApiModelProperty(value = "ciamId", readOnly = true)
	@JsonProperty("ciamId")
	@NotEmpty(message = "ciamId cannot be blank.")
	private String ciamId;
	
	public String getCiamId() {
		return ciamId;
	}
	public void setCiamId(String ciamId) {
		this.ciamId = ciamId;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getStartTime() {
		return startTime;
	}
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}
	public String getEndTime() {
		return endTime;
	}
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	public String getLicenceplate() {
		return licenceplate;
	}
	public void setLicenceplate(String licenceplate) {
		this.licenceplate = licenceplate;
	}
	public List<Barrier> getBarriers() {
		return barriers;
	}
	public void setBarriers(List<Barrier> barriers) {
		this.barriers = barriers;
	}
	public ParkingSlot getParkingSlot() {
		return parkingSlot;
	}
	public void setParkingSlot(ParkingSlot parkingSlot) {
		this.parkingSlot = parkingSlot;
	}
    
	
	
	
}
