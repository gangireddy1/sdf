package com.daimler.parkingTransaction.handler;

import com.daimler.parkingTransaction.db.entity.Parkingtransaction;
import com.daimler.parkingTransaction.model.ParkingBookingResponse;
import com.daimler.parkingTransaction.model.ParkingTransactionRequest;
import com.daimler.parkingTransaction.service.ParkingTransactionService;

import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
@Api(value = "Parking Transaction", description = "Endpoint for Parking Transaction List.")
@RequestMapping(value = "/parkingTransaction/v1")
public class ParkingTransactionListResource {

    private static final Logger logger = LoggerFactory.getLogger(ParkingTransactionListResource.class);
    
    
    @Autowired
    ParkingTransactionService parkingTrasactionService;

    @ApiOperation(value = "Add Parking Transaction details for Booked Parking lot")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Adding Parking Transaction is done successfully without errors."),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.") })
    
    @RequestMapping(value = "/addParkingTransaction", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ResponseEntity<ParkingBookingResponse>  addParkingTransaction(@Valid @RequestBody ParkingTransactionRequest parkingTransactionRequest) {
      
        logger.info("================Calling addParkingTransaction ===============");
    	
    	ParkingBookingResponse ParkingBookingResponse = new ParkingBookingResponse();
    	
    	 Parkingtransaction parkingTransactionRet= parkingTrasactionService.addParkingTransaction(parkingTransactionRequest);
        
    	if(null!= parkingTransactionRet.getParkingTransactionToken()) {
    	    ParkingBookingResponse.setStatusCode( "200" );
    	    ParkingBookingResponse.setStatusMessage( "Success" );
    	}else {
    	    ParkingBookingResponse.setStatusCode( "0 ");
    	    ParkingBookingResponse.setStatusMessage( "Transaction History serrvice failed with Errors." );
    	}
    	
    	
    	return new ResponseEntity < ParkingBookingResponse > (ParkingBookingResponse, HttpStatus.OK);
    	
    	
    	
    	
    }

//    @RequestMapping(value = "/viewParkingTransactions", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
//    @ResponseStatus(HttpStatus.OK)
//    public List<ParkingTransactionHistoryResponse> viewParkingTransactions() {
//
//     
//
//        System.out.println( "Calling viewParkingTransactions" );
//
//        return null;
//
//    }

} 