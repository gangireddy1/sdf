package com.daimler.parkingTransaction.service;

import com.daimler.parkingTransaction.constants.ApplicationConstants;
import com.daimler.parkingTransaction.dao.ParkingTransactionRepository;
import com.daimler.parkingTransaction.db.entity.Barrierinfo;
import com.daimler.parkingTransaction.db.entity.Parkingspace;
import com.daimler.parkingTransaction.db.entity.Parkingtransaction;
import com.daimler.parkingTransaction.model.Barrier;
import com.daimler.parkingTransaction.model.BookingDetails;
import com.daimler.parkingTransaction.model.Feature;
import com.daimler.parkingTransaction.model.Image;
import com.daimler.parkingTransaction.model.ParkingSlot;
import com.daimler.parkingTransaction.model.ParkingTransactionRequest;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ParkingTransactionService{
	
    
    private static final Logger logger = LoggerFactory.getLogger(ParkingTransactionService.class);
    
	@Autowired
	ParkingTransactionRepository parkingTransactionRepository;
	
	@Autowired
	DataEncryptionDecryptionService crytoService;
	
	public Parkingtransaction addParkingTransaction(ParkingTransactionRequest parkingTransactionRequest){
		
	    logger.info( "Calling addParkingTransaction");

		 Parkingtransaction parkingTransactionRet  = new Parkingtransaction();
	        try {
	        	
	            Barrierinfo barrierInfo = new Barrierinfo();
	        	Parkingspace parkingSpace = new Parkingspace();  
	        	BookingDetails bookingDetails = parkingTransactionRequest.getBookingDetails();
	        	bookingDetails.getCiamId();
	        	List<Barrier> barriers= bookingDetails.getBarriers();
	        	
	        	for(Barrier barrier : barriers){
	        		
	        		if(barrier.getPosition().equalsIgnoreCase( ApplicationConstants.BARRIER_ENTRY_EXIT ) ){
	        			 barrierInfo.setOpenBarrierCount( 0 );
	        			 barrierInfo.setOpenBarrierId( barrier.getUuid());
	        			 barrierInfo.setClosingBarrierId(crytoService.encryptText(barrier.getUuid()));
		     	         barrierInfo.setCloseBarrierCount(  0 );
		     	        barrierInfo.setType(ApplicationConstants.BARRIER_ENTRY_EXIT);
	        		}else if(barrier.getPosition().equalsIgnoreCase( ApplicationConstants.BARRIER_ENTRY ) ){
	        			 barrierInfo.setOpenBarrierCount( 0 );
	        			 barrierInfo.setOpenBarrierId(crytoService.encryptText(barrier.getUuid()));
	        			 barrierInfo.setType(ApplicationConstants.BARRIER_ENTRY);
	        		}else if(barrier.getPosition().equalsIgnoreCase( ApplicationConstants.BARRIER_EXIT ) ){
	        			barrierInfo.setClosingBarrierId(crytoService.encryptText(barrier.getUuid()));
	     	            barrierInfo.setCloseBarrierCount( 0 );
	     	            barrierInfo.setType(ApplicationConstants.BARRIER_EXIT );
	        			
	        		}
	        	}

	            ArrayList<Barrierinfo> barrierInfos = new ArrayList<Barrierinfo>();
	            barrierInfos.add( barrierInfo );

	            ParkingSlot parkingSlot = bookingDetails.getParkingSlot();
	           
	            List<Feature> features= parkingSlot.getFeatures();
	            for(Feature feature : features){
	            	 parkingSpace.setFeature( feature.getName() );
	            }
	           
	            parkingSpace.setAccessMethod( parkingSlot.getAccessMethod() );
	            parkingSpace.setDescription(  parkingSlot.getDescription() );
	            
	            List<Image> images= parkingSlot.getImages();
	            for(Image image : images){
	            	 parkingSpace.setImageUrl( image.getUrl() );
	            }
	            
	           
	            parkingSpace.setLatitude( parkingSlot.getLatitude() );
	            parkingSpace.setLongitude(  parkingSlot.getLongitude() );
	            
	            
	            parkingSpace.setStartTime(bookingDetails.getStartTime());
	            parkingSpace.setType( parkingSlot.getType().getName());

	           
	            Parkingtransaction parkingTransaction = new Parkingtransaction();
	            parkingTransaction.setActive( ApplicationConstants.ACTIVE_STATUS );
	            parkingTransaction.setCiamid( crytoService.encryptText(bookingDetails.getCiamId()) );
	            parkingTransaction.setCreationTime(new java.util.Date()  );
	            parkingTransaction.setLicencePlate( crytoService.encryptText(bookingDetails.getLicenceplate()) );
	            parkingTransaction.setNotificationNumber( parkingTransactionRequest.getNotificationId() );
	            parkingTransaction.setParkingCost(  parkingSlot.getPriceTotal() );
	            parkingTransaction.setStatus( ApplicationConstants.BOOKED );
	            parkingTransaction.setBookingId( bookingDetails.getUuid());
	            parkingTransaction.setNotificationNumber( parkingTransactionRequest.getNotificationId() );
	            parkingTransaction.setPaymentTransactionNumber( crytoService.encryptText( parkingTransactionRequest.getTxnID()) );
	            
	            double duration = getParkingDuration(bookingDetails.getStartTime(),bookingDetails.getEndTime());
	            
	            parkingTransaction.setParkingDuration( duration );
	            parkingTransaction.setServiceProvider( ApplicationConstants.SERVICE_PROVIDER);
	            parkingTransaction.setUpdationTime( null );

	            parkingSpace.setEndTime(bookingDetails.getEndTime()) ;
	            
	            
	            ArrayList<Parkingspace> parkingSpaces = new ArrayList<Parkingspace>();
	            parkingSpaces.add( parkingSpace );

	            parkingTransaction.setBarrierinfos( barrierInfos );
	            parkingTransaction.setParkingspaces(  parkingSpaces );

	            barrierInfo.setParkingtransaction( parkingTransaction );
	            parkingSpace.setParkingtransaction( parkingTransaction );

	            
	            
	            parkingTransactionRet =   parkingTransactionRepository.save( parkingTransaction );
	           
	            logger.info("ParkingTransaction History is saved successfully  ");
	            
	        } catch ( Exception e ) {
	        e.printStackTrace();
	        }
	        
		return parkingTransactionRet;
		
	}
	
	public void viewParkingSpaces(){
		 /*  List<ParkingTransaction> prkList = (List<ParkingTransaction>) transactionDaoRepository.findAll();

	        
	         * for(ParkingTransaction tran : prkList){
	         * System.out.println("Parking Transaction Details : =======  "+tran.toString());
	         * System.out.println("token : "+tran.getParkingTransactionToken());
	         * //List<BarrierInfo> barrierInfos = tran.getBarrierInfos();
	         * //for(BarrierInfo barrierInfo : barrierInfos){
	         * System.out.println("Parking Barrier Info :: ====== "+tran.getBarrierInfos().get(0).toString());
	         * //}
	         * //List<ParkingSpace> parkingSpaces = tran.getParkingSpaces();
	         * //for(ParkingSpace parkingSpace : parkingSpaces){
	         * System.out.println("Parking Space Info :: ====== "+tran.getParkingSpaces().get(0).toString());
	         * //
	         * //}
	         * }
	         

	        System.out.println( "==========================================with CIAM ID======================================================" );
	        List<ParkingTransaction> parkingList = (List<ParkingTransaction>) transactionDaoRepository.getParkingSpaceDetailsByCiamId( "C7887" );
	        for ( ParkingTransaction parkingTransaction : parkingList ) {
	            System.out.println( "Parking Transaction Details : =======  " + parkingTransaction.toString() );
	            System.out.println( "token : " + parkingTransaction.getParkingTransactionToken() );

	            // List<BarrierInfo> barrierInfos = tran.getBarrierInfos();
	            // for(BarrierInfo barrierInfo : barrierInfos){
	            System.out.println( "Parking Barrier Info :: ====== " + parkingTransaction.getBarrierInfos().get( 0 ).toString() );
	            // }

	            // List<ParkingSpace> parkingSpaces = tran.getParkingSpaces();
	            // for(ParkingSpace parkingSpace : parkingSpaces){
	            // System.out.println("Parking Space Info :: ====== "+parkingTransaction.getParkingSpace());
	            //
	            // }
	        }
	        System.out.println( "================================================================================================" );*/
	}
	
	
	
	private static double getParkingDuration(String sDate1, String sDate2) throws ParseException {

        Date date1 = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" ).parse( sDate1 );
        Date date2 = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'" ).parse( sDate2 );

        long diff = date2.getTime() - date1.getTime();

        long minutes = TimeUnit.MILLISECONDS.toMinutes( diff );

        long Hour = (long) Math.floor( minutes / 60 );
        long Minutes = minutes % 60;

        double rate = 0.016667;
        double duration = Hour + ( Minutes * rate );
        
        duration= Double.parseDouble(new DecimalFormat("0.00").format(duration));
        
        return duration;
    }
}