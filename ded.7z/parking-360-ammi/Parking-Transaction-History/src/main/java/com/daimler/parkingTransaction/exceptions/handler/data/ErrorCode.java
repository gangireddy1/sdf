package com.daimler.parkingTransaction.exceptions.handler.data;


import com.fasterxml.jackson.annotation.JsonValue;

/*
 * When adding new error codes, please also update resources/swagger/swagger-api-description.txt
 */
public enum ErrorCode {
    GENERAL_FAILURE(7001),
    INVALID_PARAMETER(7003),
    MISSING_PARAMETER(7004),
    PROVIDER_ERROR(7007),
    AUTHORIZATION_ERROR(7008),
    AREA_TOO_LARGE(7009),
    MISSING_PAYLOAD(7010);

    private final int value;

    ErrorCode(int value) {
        this.value = value;
    }


    @JsonValue
    public int getValue() {
        return value;
    }
}
