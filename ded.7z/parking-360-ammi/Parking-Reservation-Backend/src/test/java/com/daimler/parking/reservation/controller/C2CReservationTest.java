package com.daimler.parking.reservation.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.daimler.parking.reservation.ParkingSpaceBackendApplication;
import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.authorization.CORSFilter;
import com.daimler.parking.reservation.handler.C2CBookingHandler;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.Barrier;
import com.daimler.parking.reservation.model.ExclusiveFor;
import com.daimler.parking.reservation.model.Feature;
import com.daimler.parking.reservation.model.Image;
import com.daimler.parking.reservation.model.ParkingGarageAddress;
import com.daimler.parking.reservation.model.ParkingSlot;
import com.daimler.parking.reservation.model.Type;
import com.daimler.parking.reservation.request.BookingRequest;
import com.daimler.parking.reservation.request.EventNotificationRequest;
import com.daimler.parking.reservation.request.ParkingTransactionRequest;
import com.daimler.parking.reservation.request.PaymentRequest;
import com.daimler.parking.reservation.response.BookingDetails;
import com.daimler.parking.reservation.response.EventNotificationResponse;
import com.daimler.parking.reservation.response.ParkingBookingResponse;
import com.daimler.parking.reservation.response.ParkingResponse;
import com.daimler.parking.reservation.response.PaymentResponse;
import com.daimler.parking.reservation.services.CIAMService;
import com.daimler.parking.reservation.services.NotificationService;
import com.daimler.parking.reservation.services.ParkingTransactionHistoryService;
import com.daimler.parking.reservation.services.PaymentService;
import com.fasterxml.jackson.databind.ObjectMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=ParkingSpaceBackendApplication.class)
@WebAppConfiguration
public class C2CReservationTest {

	private MockMvc mockMvc;

	@Mock
	private C2CManager c2cmanager;

	@Mock
	private HttpServletRequest request;

	@Mock
	private CIAMService ciamService;

	@Mock
	private AmpidoAdapter ampidoAdapter;

	@Mock
	private C2CBookingHandler c2cBookingHandler;

	@Mock
	private NotificationService notificationService;

	@Mock
	private PaymentService paymentService;

	@Mock
	private ParkingTransactionHistoryService parkingTransactionHistoryService;

	@InjectMocks
	private C2CReservation parkingReservationController;

	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders
				.standaloneSetup(parkingReservationController)
				.addFilters(new CORSFilter())
				.build();
	}

	@Test
	public void testBookParkingSpace() throws Exception {

		Mockito.when(c2cmanager.getCiamService()).thenReturn(ciamService);

		Mockito.when(ciamService.isAuthorized(request)).thenReturn(true);

		Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);

		BookingDetails bookingDetails = new BookingDetails();

		BookingRequest bookingRequest = new BookingRequest();
		bookingRequest.setStartTime("2016-06-22'T'14:13:20.001'Z'");
		bookingRequest.setEndTime("2016-06-22'T'14:13:20.001'Z'");
		bookingRequest.setLicencePlate("2016-06-22'T'14:13:20.001'Z'");
		bookingRequest.setSlotId("Slot-123");

		Type parkingSlotType01 = new Type();
		parkingSlotType01.setId("1001");
		parkingSlotType01.setName("Garage");

		Feature parkingSlotFeature01 = new Feature();
		parkingSlotFeature01.setId("2001");
		parkingSlotFeature01.setName("EV loading station available");
		List<Feature> parkingFeautures = new ArrayList<Feature>();
		parkingFeautures.add(parkingSlotFeature01);

		ExclusiveFor parkingSlotExclusive01 = new ExclusiveFor();
		ExclusiveFor parkingSlotExclusive02 = new ExclusiveFor();
		parkingSlotExclusive01.setName("Mercedes Benz");
		parkingSlotExclusive02.setName("Smart");
		List<ExclusiveFor> parkingExclusives = new ArrayList<ExclusiveFor>();
		parkingExclusives.add(parkingSlotExclusive01);
		parkingExclusives.add(parkingSlotExclusive02);

		Image parkingSlotImage01 = new Image();
		parkingSlotImage01.setType("Mercesed Benz Parking slots");
		parkingSlotImage01
		.setUrl("http://images.all-free-download.com/images/graphiclarge/daisy_pollen_flower_220533.jpg");
		List<Image> parkingImages = new ArrayList<Image>();
		parkingImages.add(parkingSlotImage01);

		ParkingSlot parkingSlot = new ParkingSlot();
		parkingSlot.setType(parkingSlotType01);
		parkingSlot.setFeatures(parkingFeautures);
		parkingSlot.setExclusiveFor(parkingExclusives);
		parkingSlot.setImages(parkingImages);
		parkingSlot.setUuid("20170004");
		parkingSlot.setFreeUntil("Jun 20, 2017 9:13:42 AM");
		parkingSlot.setPriceFirstHour(1f);
		parkingSlot.setPriceTotal(2f);
		parkingSlot.setLatitude(48.7666667);
		parkingSlot.setLongitude(9.1833333);
		parkingSlot.setAccessMethod("barrier");
		parkingSlot.setAccessRestriction("Euro 6 vehicles only");
		parkingSlot.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
		parkingSlot.setDescription("It is a private parking lot");
		parkingSlot.setCountry("DEU");
		parkingSlot.setCity("Köln");
		parkingSlot.setPostalCode("50679");
		parkingSlot.setStreetName("Charles-de-Gaulle-Platz");
		parkingSlot.setStreetNumber("1 - 3");

		Barrier barrier01 = new Barrier();
		barrier01.setUuid("2017003");
		barrier01.setPosition("Inlet");
		Barrier barrier02 = new Barrier();
		barrier02.setUuid("2017003");
		barrier02.setPosition("Inlet");

		List<Barrier> barriers = new ArrayList<Barrier>();
		barriers.add(barrier01);
		barriers.add(barrier02);

		bookingDetails.setCiamId("CIAM-123");
		bookingDetails.setUuid("Slot-123");
		bookingDetails.setBarriers(barriers);
		bookingDetails.setStartTime("2016-06-22'T'14:13:20.001'Z'");
		bookingDetails.setEndTime("2016-06-24'T'14:13:20.001'Z'");
		bookingDetails.setLicenceplate("KA04JH1793");
		bookingDetails.setParkingSlot(parkingSlot);
		bookingDetails.setStatusCode("200");
		bookingDetails.setStatusMessage("Parking Reservation is done successfully without errors.");

		Mockito.when(ampidoAdapter.bookParkingSpace(bookingRequest)).thenReturn(bookingDetails);

		PaymentRequest paymentRequest = new PaymentRequest();

		paymentRequest.setAccountHolderName("Mr. Sumit Ranjan");
		paymentRequest.setAccountNumber("99999999999999");
		paymentRequest.setExpiresDate("2016-06-24'T'14:13:20.001'Z'");

		PaymentResponse paymentResponse = new PaymentResponse();

		Mockito.when(c2cmanager.getC2CBookingHandler()).thenReturn(c2cBookingHandler);

		Mockito.when(c2cBookingHandler.getPaymentService()).thenReturn(paymentService);

		Mockito.when(paymentService.addOrder(paymentRequest)).thenReturn(paymentResponse);

		EventNotificationRequest notificationRequest = new EventNotificationRequest();
		ParkingGarageAddress address = new ParkingGarageAddress();
		address.setBuildingNo("B123");
		address.setCity("Munich");
		address.setCountry("Germany");
		address.setStreet("Munich Street");
		address.setZipcode("560066");
		notificationRequest.setDuration("2hrs");
		notificationRequest.setEndDateTime("06/16/2017");
		notificationRequest.setEventType("local");
		notificationRequest.setFinId("F123");
		notificationRequest.setParkingFacilityName("Munich Facility");
		notificationRequest.setPrice("2$");
		notificationRequest.setStartDateTime("06/14/2017");
		notificationRequest.setUserId("U123");
		notificationRequest.setAddress(address);

		ParkingTransactionRequest parkingTxnReq = new ParkingTransactionRequest();

		parkingTxnReq.setBookingResponse(bookingDetails);
		parkingTxnReq.setServiceProvider("AMPIDO");

		EventNotificationResponse notificationResponse = new EventNotificationResponse();

		Mockito.when(c2cBookingHandler.getNotificationService()).thenReturn(notificationService);

		Mockito.when(notificationService.addNotification(notificationRequest)).thenReturn(notificationResponse);

		parkingTxnReq.setNotificationId("N-123");
		parkingTxnReq.setTxnID("T-123");

		ParkingBookingResponse parkingBookingResponse= new ParkingBookingResponse();

		Mockito.when(c2cBookingHandler.getParkingTransactionHistoryService()).thenReturn(parkingTransactionHistoryService);


		System.out.println( "Transaction Histoty Request" );

		Mockito.when(parkingTransactionHistoryService.addParkingTransactionHistory(parkingTxnReq)).thenReturn(parkingBookingResponse);

		mockMvc.perform(
				post("/c2creservation/v1/bookParkingSpace")
				.contentType(MediaType.APPLICATION_JSON)
				.content(asJsonString(bookingRequest)))
		.andExpect(status().isOk());

	}

	public static String asJsonString(final Object obj) {
		try {
			final ObjectMapper mapper = new ObjectMapper();
			return mapper.writeValueAsString(obj);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

}
