package com.daimler.parking.reservation.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;


import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.daimler.parking.reservation.ParkingSpaceBackendApplication;
import com.daimler.parking.reservation.adapters.ampido.AmpidoAdapter;
import com.daimler.parking.reservation.authorization.CORSFilter;
import com.daimler.parking.reservation.handler.C2CBookingHandler;
import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.ExclusiveFor;
import com.daimler.parking.reservation.model.Feature;
import com.daimler.parking.reservation.model.Image;
import com.daimler.parking.reservation.model.ParkingSlot;
import com.daimler.parking.reservation.model.Type;
import com.daimler.parking.reservation.response.ParkingResponse;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes=ParkingSpaceBackendApplication.class)
@WebAppConfiguration
public class AccumulatorTest {

	private MockMvc mockMvc;

	@Mock
	private C2CManager c2cmanager;

	@Mock
	private AmpidoAdapter ampidoAdapter;

	@Mock
	private C2CBookingHandler c2cBookingHandler;

	@InjectMocks
	private Accumulator accumulatorController;

	@Before
	public void init(){
		MockitoAnnotations.initMocks(this);
		mockMvc = MockMvcBuilders
				.standaloneSetup(accumulatorController)
				.addFilters(new CORSFilter())
				.build();
	}

	@Test
	public void testGetParkingSpaceList() throws Exception {

		Mockito.when(c2cmanager.getAmpidoAdapter()).thenReturn(ampidoAdapter);

		ParkingResponse parkingSpaceResponse  = new ParkingResponse();

		ParkingSlot parkingSlot1 = new ParkingSlot();
		ParkingSlot parkingSlot2 = new ParkingSlot();
		ParkingSlot parkingSlot3 = new ParkingSlot();

		List<ParkingSlot> parkingSlots = new ArrayList<ParkingSlot>();

		Type parkingSlotType01 = new Type();
		parkingSlotType01.setId("1001");
		parkingSlotType01.setName("Garage");

		Feature parkingSlotFeature01 = new Feature();
		parkingSlotFeature01.setId("2001");
		parkingSlotFeature01.setName("EV loading station available");
		List<Feature> parkingFeautures = new ArrayList<Feature>();
		parkingFeautures.add(parkingSlotFeature01);

		ExclusiveFor parkingSlotExclusive01 = new ExclusiveFor();
		ExclusiveFor parkingSlotExclusive02 = new ExclusiveFor();
		parkingSlotExclusive01.setName("Mercedes Benz");
		parkingSlotExclusive02.setName("Smart");
		List<ExclusiveFor> parkingExclusives = new ArrayList<ExclusiveFor>();
		parkingExclusives.add(parkingSlotExclusive01);
		parkingExclusives.add(parkingSlotExclusive02);

		Image parkingSlotImage01 = new Image();
		parkingSlotImage01.setType("Mercesed Benz Parking slots");
		parkingSlotImage01.setUrl("http://images.all-free-download.com/images/graphiclarge/daisy_pollen_flower_220533.jpg");
		List<Image> parkingImages = new ArrayList<Image>();
		parkingImages.add(parkingSlotImage01);

		parkingSlot1.setType(parkingSlotType01);
		parkingSlot1.setFeatures(parkingFeautures);
		parkingSlot1.setExclusiveFor(parkingExclusives);
		parkingSlot1.setImages(parkingImages);
		parkingSlot1.setUuid("2017P0001");
		parkingSlot1.setStartTime("2016-06-22'T'14:13:20.001'Z'");
		parkingSlot1.setFreeUntil("2016-06-22'T'15:13:20.001'Z'");
		parkingSlot1.setPriceTotal(2f);
		parkingSlot1.setLatitude(48.7666667);
		parkingSlot1.setLongitude(9.1833333);
		parkingSlot1.setAccessMethod("barrier");
		parkingSlot1.setAccessRestriction("Euro 6 vehivles only");
		parkingSlot1.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
		parkingSlot1.setDescription("It is a private parking lot");
		parkingSlot1.setCountry("DEU");
		parkingSlot1.setCity("Berlin");
		parkingSlot1.setPostalCode("50679");
		parkingSlot1.setStreetName("Romanshorner Weg");
		parkingSlot1.setStreetNumber("192");

		parkingSlot2.setType(parkingSlotType01);
		parkingSlot2.setFeatures(parkingFeautures);
		parkingSlot2.setExclusiveFor(parkingExclusives);
		parkingSlot2.setImages(parkingImages);
		parkingSlot2.setUuid("2017P0002");
		parkingSlot2.setStartTime("2016-06-22'T'14:13:20.001'Z'");
		parkingSlot2.setFreeUntil("2016-06-22'T'15:13:20.001'Z'");
		parkingSlot2.setPriceTotal(3);
		parkingSlot2.setLatitude(46.520348);
		parkingSlot2.setLongitude(11.402354);
		parkingSlot2.setAccessMethod("barrier");
		parkingSlot2.setAccessRestriction("Euro 6 vehivles only");
		parkingSlot2.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
		parkingSlot2.setDescription("It is a private parking lot");
		parkingSlot2.setCountry("DEU");
		parkingSlot2.setCity("Berlin");
		parkingSlot2.setPostalCode("50539");
		parkingSlot2.setStreetName("Joachimsthaler Straßet");
		parkingSlot2.setStreetNumber("30");

		Feature parkingSlotFeature03 = new Feature();
		parkingSlotFeature01.setId("2001");
		parkingSlotFeature03.setName("No EV loading station available");
		List<Feature> parkingFeautures03 = new ArrayList<Feature>();
		parkingFeautures03.add(parkingSlotFeature03);

		List<ExclusiveFor> parkingExclusives03 = new ArrayList<ExclusiveFor>();

		parkingExclusives03.add(parkingSlotExclusive01);

		parkingSlot3.setType(parkingSlotType01);
		parkingSlot3.setFeatures(parkingFeautures03);
		parkingSlot3.setExclusiveFor(parkingExclusives03);
		parkingSlot3.setImages(parkingImages);
		parkingSlot3.setUuid("2017P0003");
		parkingSlot3.setStartTime("2016-06-22'T'14:13:20.001'Z'");
		parkingSlot3.setFreeUntil("2016-06-22'T'15:13:20.001'Z'");
		parkingSlot3.setPriceTotal(2);
		parkingSlot3.setLatitude(46.7666667);
		parkingSlot3.setLongitude(9.1833333);
		parkingSlot3.setAccessMethod("barrier");
		parkingSlot3.setAccessRestriction("Euro 6 vehivles only");
		parkingSlot3.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
		parkingSlot3.setDescription("It is a private parking lot");
		parkingSlot3.setCountry("DEU");
		parkingSlot3.setCity("Berlin");
		parkingSlot3.setPostalCode("50679");
		parkingSlot3.setStreetName("Charles-de-Gaulle-Platz");
		parkingSlot3.setStreetNumber("13");

		parkingSlots.add(parkingSlot1);
		parkingSlots.add(parkingSlot2);
		parkingSlots.add(parkingSlot3);

		parkingSpaceResponse.setStatusCode("200");
		parkingSpaceResponse.setStatusMessage("Successful");
		parkingSpaceResponse.setErrors(null);
		parkingSpaceResponse.setParkingSlots(parkingSlots);

		Mockito.when(ampidoAdapter.getParkingSpaceList(48.7666667, 9.1833333, 48.7666667, 9.1833333,"2016-06-22'T'14:13:20.001'Z'" ,"2016-06-22'T'14:13:20.001'Z'"))
		.thenReturn(parkingSpaceResponse);

		mockMvc.perform(MockMvcRequestBuilders.get("/accumulator/v1/c2creservation/parkingSpaceList"
				+"?latitudeTopLeft=48.7666667&longitudeTopLeft=9.1833333&latitudeBottomRight=48.7666667&longitudeBottomRight=9.1833333&"
				+"startTime=2017-04-18T11:05:55.312Z&endTime=2017-04-18T11:05:55.312Z"))
		.andExpect(status().isOk());
	}
}
