package com.daimler.parking.reservation.services;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.request.ParkingTransactionRequest;
import com.daimler.parking.reservation.response.ParkingBookingResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ParkingTransactionHistoryService {

	private static final Logger logger = LoggerFactory.getLogger(ParkingTransactionHistoryService.class);

	RestTemplate restTemplate;

	@Bean
	public RestTemplate restTemplate() {
		return new RestTemplate();
	}

	public ParkingBookingResponse addParkingTransactionHistory(ParkingTransactionRequest parkingTxnReq)
			throws JsonParseException, JsonMappingException, IOException, KeyManagementException,
			NoSuchAlgorithmException, KeyStoreException {

	    logger.info("Invoking service addParkingTransactionHistory");
	    
		final String uri = "http://localhost:8099/parkingTransaction/v1/addParkingTransaction";

		// RestTemplate restTemplate = new RestTemplate();

		RestTemplate restTemplate = createRestTemplate();

		final HttpHeaders headers = new HttpHeaders();
		headers.setContentType(MediaType.APPLICATION_JSON);

		HttpEntity<ParkingTransactionRequest> entity = new HttpEntity<>(parkingTxnReq, headers);
		ResponseEntity<String> response = restTemplate.exchange(uri, HttpMethod.POST, entity, String.class);
		logger.info("After Calling Notification Center response status code==" + response.getStatusCode());
		ParkingBookingResponse parkingBookingResponse = new ParkingBookingResponse();
		if (response.getStatusCode().equals(HttpStatus.OK)) {
			ObjectMapper mapper = new ObjectMapper();
			parkingBookingResponse = mapper.readValue(response.getBody(), ParkingBookingResponse.class);
		}
		
		 logger.info("parkingBookingResponse == "+parkingBookingResponse.getStatusMessage());
		 
		return parkingBookingResponse;

	}

	public RestTemplate createRestTemplate()
			throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException {
		SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(
				new SSLContextBuilder().loadTrustMaterial(null, new TrustSelfSignedStrategy()).build());
		HttpClient httpClient = HttpClients.custom().setSSLSocketFactory(socketFactory).build();
		HttpComponentsClientHttpRequestFactory requestFactory = new HttpComponentsClientHttpRequestFactory();
		requestFactory.setHttpClient(httpClient);
		restTemplate = new RestTemplate(requestFactory);
		return restTemplate;

	}

	public void updateParkingTransactionHistory() {

	}

	public void viewParkingTransactionHistoryList() {

	}

}
