package com.daimler.parking.reservation.response;

import java.io.Serializable;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.daimler.parking.reservation.exceptions.handler.data.ErrorObject;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import io.swagger.annotations.ApiModelProperty;

public class PaymentResponse implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@ApiModelProperty(value = "Transaction Response Message Id", readOnly = true)
	@JsonProperty("txnId")
	@NotEmpty(message = "transactionID cannot be blank.")
	private String txnId;
	
	@ApiModelProperty(value = "Errors Code", readOnly = true)
	@JsonProperty("errorCode")
//	@JsonIgnoreProperties
	private String errorCode;
	
	@ApiModelProperty(value = "Errors Details", readOnly = true)
	@JsonProperty("errorMessage")
//	@JsonIgnoreProperties
	private String errorMessage;

	@ApiModelProperty(value = "Payment Amount", readOnly = true)
	@JsonProperty("paymentAmount")
	@NotEmpty(message = "paymentAmount cannot be blank.")
	private String paymentAmount;
	
	@ApiModelProperty(value = "Payment Date", readOnly = true)
	@JsonProperty("paymentDate")
	@NotEmpty(message = "paymentDate cannot be blank.")
	private String paymentDate;

	public String getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(String paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getPaymentDate() {
		return paymentDate;
	}

	public void setPaymentDate(String paymentDate) {
		this.paymentDate = paymentDate;
	}

	public String getTxnId() {
		return txnId;
	}

	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	
	
	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getErrorMessage() {
		return errorMessage;
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}


}
