package com.daimler.parking.reservation.model.request;

import java.util.List;


public class ParkingRequest {
	
	private List<ParkingSlotAmpido> results;
	
	private Meta meta;

	public List<ParkingSlotAmpido> getResults() {
		return results;
	}

	public void setResults(List<ParkingSlotAmpido> results) {
		this.results = results;
	}

	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}
	

}
