package com.daimler.parking.reservation.handler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.daimler.parking.reservation.services.NotificationService;
import com.daimler.parking.reservation.services.ParkingTransactionHistoryService;
import com.daimler.parking.reservation.services.PaymentService;
import com.daimler.parking.reservation.services.SessionContextService;

@Component
public class C2CBookingHandler {

	@Autowired
	private NotificationService notificationService;
	
	@Autowired
	private ParkingTransactionHistoryService parkingTransactionHistoryService;

	@Autowired
	private PaymentService paymentService;
	
	@Autowired
	private SessionContextService sessionContextService;

	public NotificationService getNotificationService() {
		return notificationService;
	}

	public void setNotificationService(NotificationService notificationService) {
		this.notificationService = notificationService;
	}

	public ParkingTransactionHistoryService getParkingTransactionHistoryService() {
		return parkingTransactionHistoryService;
	}

	public void setParkingTransactionHistoryService(ParkingTransactionHistoryService parkingTransactionHistoryService) {
		this.parkingTransactionHistoryService = parkingTransactionHistoryService;
	}

	public PaymentService getPaymentService() {
		return paymentService;
	}

	public void setPaymentService(PaymentService paymentService) {
		this.paymentService = paymentService;
	}

	public SessionContextService getSessionContextService() {
		return sessionContextService;
	}

	public void setSessionContextService(SessionContextService sessionContextService) {
		this.sessionContextService = sessionContextService;
	}
	
	

}
