package com.daimler.parking.reservation.model;

import javax.validation.constraints.NotNull;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
@ApiModel(value = "Parking Garage Address", description = " Garage Address Information")
public class ParkingGarageAddress {
	
	 @ApiModelProperty(value="Building Number",dataType="String",required=true)
	 @NotNull(message = "Building No is required.")
	private String buildingNo;
	 @ApiModelProperty(value="Street number or name",dataType="String", required=true)
	 @NotNull(message = "Street is required.")
	private String street;
	 @ApiModelProperty(value="ZipCode",dataType="String" ,required=true)
	 @NotNull(message = "ZipCode is required.")
	private String zipcode;
	 @ApiModelProperty(value="City",dataType="String",required=true)
	 @NotNull(message = "City is required.")
	private String city;
     @ApiModelProperty(value="Country",dataType="String",required=true)
     @NotNull(message = "Country is required.")
	private String country;
	/**
	 * @return the buildingNo
	 */
	public String getBuildingNo() {
		return buildingNo;
	}
	/**
	 * @param buildingNo the buildingNo to set
	 */
	public void setBuildingNo(String buildingNo) {
		this.buildingNo = buildingNo;
	}
	/**
	 * @return the street
	 */
	public String getStreet() {
		return street;
	}
	/**
	 * @param street the street to set
	 */
	public void setStreet(String street) {
		this.street = street;
	}
	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}
	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}
	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}

     
     
     
}
