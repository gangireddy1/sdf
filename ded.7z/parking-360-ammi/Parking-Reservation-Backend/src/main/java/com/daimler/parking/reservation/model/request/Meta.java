package com.daimler.parking.reservation.model.request;

public class Meta {
	private int count;

    private int totalPages;

    public int getCount ()
    {
        return count;
    }

    public void setCount (int count)
    {
        this.count = count;
    }

    public int getTotalPages ()
    {
        return totalPages;
    }

    public void settotalPages (int totalPages)
    {
        this.totalPages = totalPages;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [count = "+count+", total-pages = "+totalPages+"]";
    }

}
