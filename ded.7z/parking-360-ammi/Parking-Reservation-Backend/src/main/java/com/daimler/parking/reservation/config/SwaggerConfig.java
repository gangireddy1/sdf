package com.daimler.parking.reservation.config;

import com.fasterxml.classmate.TypeResolver;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

import java.io.InputStream;
import java.time.LocalDate;

import static springfox.documentation.schema.AlternateTypeRules.newRule;

/**
 * Swagger Configuration: force use of overridden properties from swagger.properties in src/main/resources
 * and provides default behaviour where to scan for rest api resources.
 */
@PropertySource("classpath:swagger/swagger.properties")
@Configuration
@EnableSwagger2
public class SwaggerConfig {

    //Base Package where to start to scan for Rest API
    private static final String REST_PACKAGE_PATH = "com.daimler.parking.reservation.controller";

    @Autowired
    private TypeResolver typeResolver;

    /**
     * Provides basic configuration for Swagger.
     * See at http://springfox.github.io/springfox/docs/current/ for more configuration options.
     *
     * @return A new Docket with configuration for this project.
     */
    @Bean
    public Docket parkingReservationServiceApi() {
        return new Docket(DocumentationType.SWAGGER_2).select()
                .apis(RequestHandlerSelectors.basePackage(REST_PACKAGE_PATH))
                .paths(PathSelectors.any())
                .build().pathMapping("/")
                .directModelSubstitute(LocalDate.class, String.class)
                .genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(newRule(typeResolver.resolve(DeferredResult.class, typeResolver.resolve(ResponseEntity.class, WildcardType.class)), typeResolver.resolve(WildcardType.class)))
                .useDefaultResponseMessages(false)
                .apiInfo(getApiInfo());
    }

    private ApiInfo getApiInfo() {
        return new ApiInfoBuilder()
                .title("C2C-Reservation API")
                .description(getApiDescription("<Missing API description>"))
                .license(null)
                .version("1.0")
                .build();
    }

    private String getApiDescription(String defaultText) {
        InputStream is = ClassLoader.getSystemResourceAsStream("swagger/swagger-api-description.txt");
        if (null != is) {
            try (java.util.Scanner s = new java.util.Scanner(is)) {
                if (s.useDelimiter("\\A").hasNext()) {
                    return s.next();
                }
            }
        }
        return defaultText;
    }
}
