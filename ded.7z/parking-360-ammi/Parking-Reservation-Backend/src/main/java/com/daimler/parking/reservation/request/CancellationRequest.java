package com.daimler.parking.reservation.request;

import org.hibernate.validator.constraints.NotEmpty;

public class CancellationRequest extends BaseRequest {

	private String cancelReason;

	@NotEmpty(message = "bookingId cannot be blank.")
	private String bookingId;

	public String getCancelReason() {
		return cancelReason;
	}

	public void setCancelReason(String cancelReason) {
		this.cancelReason = cancelReason;
	}

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

}
