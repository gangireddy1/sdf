package com.daimler.parking.reservation.request;

import org.hibernate.validator.constraints.NotEmpty;

public class ParkingExtensionRequest extends BaseRequest {

	@NotEmpty(message = "bookingId cannot be blank.")
	private String bookingId;

	private String parkingEndTime;

	public String getBookingId() {
		return bookingId;
	}

	public void setBookingId(String bookingId) {
		this.bookingId = bookingId;
	}

	public String getParkingEndTime() {
		return parkingEndTime;
	}

	public void setParkingEndTime(String parkingEndTime) {
		this.parkingEndTime = parkingEndTime;
	}

}
