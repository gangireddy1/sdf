package com.daimler.parking.reservation.exceptions.handler;

import java.util.ArrayList;
import java.util.List;

import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.daimler.parking.reservation.exceptions.handler.data.ErrorCode;
import com.daimler.parking.reservation.exceptions.handler.data.ErrorObject;
import com.daimler.parking.reservation.response.BaseResponse;

/**
 * Exception handler class for parameter validation exceptions not handled by specific handler.
 * Logs the exception and ensures a valid response object for the client.
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@RestController
public class ParameterValidationExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ParameterValidationExceptionHandler.class);

    /**
     * Handler for constraint violation exception. Thrown by javax.validation.constraints.
     *
     * @param exception The exception which occurred
     * @return A Valid Response Object for the client.
     */
    @ExceptionHandler(ConstraintViolationException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public BaseResponse constraintErrorHandler(ConstraintViolationException exception) {

        logger.warn("A ConstraintViolationException was thrown", exception);

        List<ErrorObject> errorObjectList = new ArrayList<>();
        for (ConstraintViolation constraintViolation : exception.getConstraintViolations()) {
            ErrorObject errorObject = new ErrorObject(ErrorCode.INVALID_PARAMETER, constraintViolation.getMessage());
            errorObjectList.add(errorObject);
        }
        
        BaseResponse response = new BaseResponse();
        response.setErrors(errorObjectList);

        String logMessage = generateLogMessage(errorObjectList);

        logger.info("Application exit, {}", logMessage);

        return response;
    }

    /**
     * Handler for method argument type mismatch exception.
     *
     * @param exception The exception which occurred
     * @return A Valid Response Object for the client.
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public BaseResponse typeMismatchErrorHandler(MethodArgumentTypeMismatchException exception) {

        logger.warn("A MethodArgumentTypeMismatchException was thrown", exception);

        List<ErrorObject> errorObjectList = new ArrayList<>();
        String errorMessage = exception.getName() + " has the wrong format, must be " + exception.getRequiredType().getName();
        ErrorObject errorObject = new ErrorObject(ErrorCode.INVALID_PARAMETER, errorMessage);
        errorObjectList.add(errorObject);
        BaseResponse response = new BaseResponse();
        response.setErrors(errorObjectList);

        logger.info("Application exit, {}", errorObjectList.get(0));

        return response;
    }

    private String generateLogMessage(List<ErrorObject> errorObjectList) {
        String logMessage = "";
        for (ErrorObject errorObject : errorObjectList) {
            logMessage += " " + errorObject;
        }
        return logMessage.trim();
    }
}
