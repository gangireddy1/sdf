package com.daimler.parking.reservation.request;

import org.hibernate.validator.constraints.NotEmpty;

public class ParkingBarrierRequest extends BaseRequest {

	@NotEmpty(message = "ciamId cannot be blank")
	private String ciamId;

	@NotEmpty(message = "barrier Uuid cannot be blank.")
	private String barrierUuid;
	
	private String barrierReason;
	

	public String getCiamId() {
		return ciamId;
	}

	public void setCiamId(String ciamId) {
		this.ciamId = ciamId;
	}

	public String getBarrierUuid() {
		return barrierUuid;
	}

	public void setBarrierUuid(String barrierUuid) {
		this.barrierUuid = barrierUuid;
	}

	public String getBarrierReason() {
		return barrierReason;
	}

	public void setBarrierReason(String barrierReason) {
		this.barrierReason = barrierReason;
	}

}
