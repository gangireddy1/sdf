package com.daimler.parking.reservation.constants;

public class ApplicationContants {
	
	public static String GRANT_TYPE_PASSWORD="password";
	public static String GRANT_TYPE_REFRESH_TOKEN="refresh_token";
	
	

}
