package com.daimler.parking.reservation.request;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.security.crypto.codec.Base64;

public class ParkingOffenderRequest extends BaseRequest {
	
	@NotEmpty(message = "BookingID cannot be blank.")
	private String uuid;
	
	@NotEmpty(message = "Offender Image cannot be blank.")
	private Base64 picture;
	
	private String description;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public Base64 getPicture() {
		return picture;
	}

	public void setPicture(Base64 picture) {
		this.picture = picture;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
