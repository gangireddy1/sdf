package com.daimler.parking.reservation.exceptions.handler;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.daimler.parking.reservation.exceptions.MissingRequestHeaderParameterException;
import com.daimler.parking.reservation.exceptions.handler.data.ErrorCode;
import com.daimler.parking.reservation.exceptions.handler.data.ErrorObject;
import com.daimler.parking.reservation.response.BaseResponse;

/**
 * Exception handler class for missing parameter exceptions not handled by specific handler.
 * Logs the exception and ensures a valid response object for the client.
 */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
@RestController
public class ParameterMissingExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(ParameterMissingExceptionHandler.class);

    /**
     * Handler for MissingServletRequestParameterException.
     *
     * @param exception The exception which occurred
     * @return A Valid Response Object for the client.
     */
    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public BaseResponse missingServletErrorHandler(MissingServletRequestParameterException exception) {

        logger.warn("A MissingServletRequestParameterException was thrown", exception);

        List<ErrorObject> errorObjectList = new ArrayList<>();
        ErrorObject errorObject = new ErrorObject(ErrorCode.MISSING_PARAMETER, exception.getMessage());
        errorObjectList.add(errorObject);
        BaseResponse response = new BaseResponse();
        response.setErrors(errorObjectList);

        logger.info("Application exit, {}", errorObjectList.get(0));

        return response;
    }

    /**
     * Handler for MissingRequestHeaderParameterException.
     *
     * @param exception The exception which occurred
     * @return A Valid Response Object for the client.
     */
    @ExceptionHandler(MissingRequestHeaderParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    @ResponseBody
    public BaseResponse missingHttpHeaderErrorHandler(MissingRequestHeaderParameterException exception)
    {
        logger.warn("A MissingRequestHeaderParameterException was thrown", exception);

        List<ErrorObject> errorObjectList = new ArrayList<>();
        ErrorObject errorObject = new ErrorObject(ErrorCode.MISSING_PARAMETER, exception.getMessage());
        errorObjectList.add(errorObject);
        BaseResponse response = new BaseResponse();
        response.setErrors(errorObjectList);

        logger.info("Application exit, {}", errorObjectList.get(0));

        return response;
    }

}
