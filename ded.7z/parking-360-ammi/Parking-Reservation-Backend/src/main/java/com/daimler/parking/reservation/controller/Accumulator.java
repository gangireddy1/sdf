package com.daimler.parking.reservation.controller;

import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.ParkingGarageAddress;
import com.daimler.parking.reservation.model.ParkingSlot;
import com.daimler.parking.reservation.request.BookingRequest;
import com.daimler.parking.reservation.request.CancellationRequest;
import com.daimler.parking.reservation.request.EventNotificationRequest;
import com.daimler.parking.reservation.request.ParkingBarrierRequest;
import com.daimler.parking.reservation.request.ParkingExtensionRequest;
import com.daimler.parking.reservation.request.ParkingOffenderRequest;
import com.daimler.parking.reservation.request.ParkingTransactionRequest;
import com.daimler.parking.reservation.request.PaymentRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.daimler.parking.reservation.response.BookingDetails;
import com.daimler.parking.reservation.response.EventNotificationResponse;
import com.daimler.parking.reservation.response.ParkingBarrierResponse;
import com.daimler.parking.reservation.response.ParkingBookingResponse;
import com.daimler.parking.reservation.response.ParkingExtensionResponse;
import com.daimler.parking.reservation.response.ParkingOffenderResponse;
import com.daimler.parking.reservation.response.ParkingResponse;
import com.daimler.parking.reservation.response.PaymentResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
@Api(value = "Search Parking Spaces ", description = "Endpoint for Retrieving C2C Parking Space.")
@RequestMapping(value = "/accumulator/v1")
public class Accumulator extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(Accumulator.class);

	@Autowired
	private C2CManager c2cmanager;

	/**
	 * Returns all parking Space details on the given latitude, longitude,radius and start time. 
	 *
	 * @param latitude: <DECIMAL> # search location
	 * @param longitude: <DECIMAL> # search location
	 * @param distance: <DECIMAL> # search radius in km. Max: 20km
	 * @param page[number]: <INTEGER> # page number of search result
	 * @param page[size]: <INTEGER> # number of results per page
	 * @param start_time: <ISO 8601> # start time of parking lot booking
	 * @param end_time: <ISO 8601> # (optional) end time of parking lot booking
	 * @param max_results: <Decimal(3)> # (optional) maximum number of parking lots in result, sorted by distance
	 * 
	 * @return    dummy static ViewParkingSpaceResponses as List
	 * @throws IOException 
	 
	**/
	 
	@CrossOrigin
	@ApiOperation(value = "Returns all parking Spaces details for the given latitude, longitude,radius and start time.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.")
	})
	@RequestMapping(value = "/c2creservation/parkingSpaceList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public ParkingResponse getParkingSpaceList(

		@ApiParam(value = "LatitudeTopLeft, range: -90.0 - 90.0", defaultValue = "48.7666667", required = true)
		@RequestParam(value = "latitudeTopLeft", required = true)
		@DecimalMin(value = "-90.0", message = "latitude must be at least -90.0")
		@DecimalMax(value = "90.0", message = "latitude can only be up to 90.0")
		double latitudeTopLeft,
		
		@ApiParam(value = "LongitudeTopLeft, range: -180.0 - 180.0", defaultValue = "9.1833333", required = true)
		@RequestParam(value = "longitudeTopLeft", required = true)
		@DecimalMin(value = "-180.0", message = "longitude must be at least -180.0")
		@DecimalMax(value = "180.0", message = "longitude can only be up to 180.0")
		double longitudeTopLeft,
		
		@ApiParam(value = "LatitudeBottomRight, range: -90.0 - 90.0", defaultValue = "48.7666667", required = true)
		@RequestParam(value = "latitudeBottomRight", required = true)
		@DecimalMin(value = "-90.0", message = "latitude must be at least -90.0")
		@DecimalMax(value = "90.0", message = "latitude can only be up to 90.0")
		double latitudeBottomRight,
		
		@ApiParam(value = "LongitudeBottomRight, range: -180.0 - 180.0", defaultValue = "9.1833333", required = true)
		@RequestParam(value = "longitudeBottomRight", required = true)
		@DecimalMin(value = "-180.0", message = "longitude must be at least -180.0")
		@DecimalMax(value = "180.0", message = "longitude can only be up to 180.0")
		double longitudeBottomRight,

		@ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-04-18T11:05:55.312Z", required = true, type="ISO 8601 Date")
		@RequestParam(value = "startTime", required = true)
//		@DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
		String startTimeI,
		
		@ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-04-18T12:05:55.312Z", required = false, type="ISO 8601 Date")
		@RequestParam(value = "endTime", required = false)
//		@DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
		String endTimeI
			) throws JsonParseException, JsonMappingException, IOException {

		logger.info("Invoking service  getParkingSpaceList");


		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
//		LocalDateTime startTime = LocalDateTime.parse(startTimeI,dateTimeFormatter);
//		LocalDateTime endTime = LocalDateTime.parse(endTimeI,dateTimeFormatter);
		
		
		ParkingResponse parkingSpaceResponse  = new ParkingResponse();
		
		parkingSpaceResponse = c2cmanager.getAmpidoAdapter().getParkingSpaceList(latitudeTopLeft,longitudeTopLeft,
				latitudeBottomRight, longitudeBottomRight,startTimeI, endTimeI);

		logger.info("Exiting  service  getParkingSpaceList");
		
		return parkingSpaceResponse;
	
	}


}
