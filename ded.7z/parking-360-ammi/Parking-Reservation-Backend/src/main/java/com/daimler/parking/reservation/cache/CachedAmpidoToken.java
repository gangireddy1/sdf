package com.daimler.parking.reservation.cache;

public class CachedAmpidoToken {
	
	private java.util.Date timeOfExpiration = null;
	private Object token = null;
	
	public Object object = null;
	

	public void CachedObject(Object obj, Object id, int minutesToLive)
    {
      this.object = obj;
      this.token = id;
      // minutesToLive of 0 means it lives on indefinitely.
      if (minutesToLive != 0)
      {
    	  timeOfExpiration = new java.util.Date();
        java.util.Calendar cal = java.util.Calendar.getInstance();
        cal.setTime(timeOfExpiration);
        cal.add(cal.MINUTE, minutesToLive);
        timeOfExpiration = cal.getTime();
      }
    }
	
	
	public boolean isExpired()
    {
        // Remember if the minutes to live is zero then it lives forever!
        if (timeOfExpiration != null)
        {
          // date of expiration is compared.
          if (timeOfExpiration.before(new java.util.Date()))
          {
            System.out.println("CachedResultSet.isExpired:  Expired fromCache! EXPIRE TIME: " + timeOfExpiration.toString() + " CURRENT TIME: " +(new java.util.Date()).toString());
            return true; 
          }
          else
          {
            System.out.println("CachedResultSet.isExpired:  Expired not from Cache!");
            return false;
          }
        }
        else // This means it lives forever!
          return false;
    }
	
	
	/*public static void main(String args[]) {
		
		CachedAmpidoToken token = new CachedAmpidoToken();
		token.CachedObject(token, "1788888TYYYYYU", 1);
		
		System.out.println(token.isExpired());
		
		
	}*/
	
}
