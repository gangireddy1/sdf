package com.daimler.parking.reservation.model.request;

import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.validator.constraints.NotEmpty;

import com.daimler.parking.reservation.model.ExclusiveFor;
import com.daimler.parking.reservation.model.Feature;
import com.daimler.parking.reservation.model.Image;
import com.daimler.parking.reservation.model.Type;
import com.daimler.parking.reservation.utility.LocalDateTimeDeserializer;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

public class ParkingSlotAmpido {
	
	@NotEmpty(message = "Slot Id cannot be blank.")
	private String slotId;

	@JsonDeserialize(using = LocalDateTimeDeserializer.class)
	private LocalDateTime freeUntil;
	
	private float priceFirstHour;
	
	private float priceTotal;
	
	@NotEmpty(message = "latitude cannot be blank.")
	private double latitude;
	
	@NotEmpty(message = "longitude cannot be blank.")
	private double longitude;
	
	@NotEmpty(message = "accessRestriction cannot be blank.")
	private String accessRestriction;
	
	@NotEmpty(message = "accessMethod cannot be blank.")
	private String accessMethod;
	
	@NotEmpty(message = "importantInformation cannot be blank.")
	private String importantInformation;
	
	@NotEmpty(message = "description cannot be blank.")
	private String description;
	
	@NotEmpty(message = "type cannot be blank.")
	private Type type;
	
	@NotEmpty(message = "features cannot be blank.")
	private List<Feature> features;
    
	@NotEmpty(message = "images cannot be blank.")
	private List<Image> images;
	
	@NotEmpty(message = "exclusiveFor cannot be blank.")
	private List<ExclusiveFor> exclusiveFor;
	
	@NotEmpty(message = "country cannot be blank.")
	private String country;
	
	@NotEmpty(message = "city cannot be blank.")
	private String city;
	
	@NotEmpty(message = "streetName cannot be blank.")
	private String streetName;
	
	@NotEmpty(message = "postalCode cannot be blank.")
	private String postalCode;
	
	@NotEmpty(message = "streetNumber cannot be blank.")
	private String streetNumber;

    public String getStreetName ()
    {
        return streetName;
    }

    public void setStreetName (String streetName)
    {
        this.streetName = streetName;
    }

    public Type getType ()
    {
        return type;
    }

    public void setType (Type type)
    {
        this.type = type;
    }

    public float getPriceTotal ()
    {
        return priceTotal;
    }

    public void setPriceTotal (float priceTotal)
    {
        this.priceTotal = priceTotal;
    }

    public String getCity ()
    {
        return city;
    }

    public void setCity (String city)
    {
        this.city = city;
    }

    public String getCountry ()
    {
        return country;
    }

    public void setCountry (String country)
    {
        this.country = country;
    }

    public LocalDateTime getFreeUntil ()
    {
        return freeUntil;
    }

    public void setFreeUntil (LocalDateTime endTime)
    {
        this.freeUntil = endTime;
    }

    public String getPostalCode ()
    {
        return postalCode;
    }

    public void setPostalCode (String postalCode)
    {
        this.postalCode = postalCode;
    }

    public List<ExclusiveFor> getExclusiveFor ()
    {
        return exclusiveFor;
    }

    public void setExclusiveFor (List<ExclusiveFor> exclusiveFor)
    {
        this.exclusiveFor = exclusiveFor;
    }

    public String getImportantInformation ()
    {
        return importantInformation;
    }

    public void setImportantInformation (String importantInformation)
    {
        this.importantInformation = importantInformation;
    }

    public String getAccessMethod ()
    {
        return accessMethod;
    }

    public void setAccessMethod (String accessMethod)
    {
        this.accessMethod = accessMethod;
    }

    public String getDescription ()
    {
        return description;
    }

    public void setDescription (String description)
    {
        this.description = description;
    }

    public float getPriceFirstHour ()
    {
        return priceFirstHour;
    }

    public void setPriceFirstHour (float priceFirstHour)
    {
        this.priceFirstHour = priceFirstHour;
    }

    public List<Feature> getFeatures ()
    {
        return features;
    }

    public void setFeatures (List<Feature> features)
    {
        this.features = features;
    }

    public List<Image> getImages ()
    {
        return images;
    }

    public void setImages (List<Image> images)
    {
        this.images = images;
    }

    public String getStreetNumber ()
    {
        return streetNumber;
    }

    public void setStreetNumber (String streetNumber)
    {
        this.streetNumber = streetNumber;
    }

    public double getLongitude ()
    {
        return longitude;
    }

    public void setLongitude (double longitude)
    {
        this.longitude = longitude;
    }

    public String getUuid ()
    {
        return slotId;
    }

    public void setUuid (String uuid)
    {
        this.slotId = uuid;
    }

    public double getLatitude ()
    {
        return latitude;
    }

    public void setLatitude (double latitude)
    {
        this.latitude = latitude;
    }

    public String getAccessRestriction ()
    {
        return accessRestriction;
    }

    public void setAccessRestriction (String accessRestriction)
    {
        this.accessRestriction = accessRestriction;
    }

    @Override
    public String toString()
    {
        return "ClassPojo [streetName = "+streetName+", type = "+type+", priceTotal = "+priceTotal+", city = "+city+", country = "+country+", freeUntil = "+freeUntil+", postalCode = "+postalCode+", exclusiveFor = "+exclusiveFor+", importantInformation = "+importantInformation+", accessMethod = "+accessMethod+", description = "+description+", priceFirstHour = "+priceFirstHour+", features = "+features+", images = "+images+", streetNumber = "+streetNumber+", longitude = "+longitude+", uuid = "+slotId+", latitude = "+latitude+", accessRestriction = "+accessRestriction+"]";
    }


}
