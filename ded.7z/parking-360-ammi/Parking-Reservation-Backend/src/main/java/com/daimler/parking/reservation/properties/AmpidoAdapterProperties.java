package com.daimler.parking.reservation.properties;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

/**
 * AMPIDO Adapater configuration parameter.
 */

@Component
@ConfigurationProperties(prefix = "adapter.ampido", ignoreUnknownFields = false)
public class AmpidoAdapterProperties {

	private String baseUrl;

	public String getBaseUrl() {
		return baseUrl;
	}

	public void setBaseUrl(String baseUrl) {
		this.baseUrl = baseUrl;
	}

}
