package com.daimler.parking.reservation.adapters.ampido;

import java.io.IOException;
import java.time.LocalDateTime;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.constants.ApplicationContants;
import com.daimler.parking.reservation.model.request.ParkingRequest;
import com.daimler.parking.reservation.properties.AmpidoAdapterProperties;
import com.daimler.parking.reservation.request.AccessTokenRequest;
import com.daimler.parking.reservation.request.BookingRequest;
import com.daimler.parking.reservation.response.AccessTokenResponse;
import com.daimler.parking.reservation.response.BookingDetails;
import com.daimler.parking.reservation.response.ParkingResponse;
import com.daimler.parking.reservation.services.MockApiaryCallService;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class AmpidoAdapter {

	private static final Logger logger = LoggerFactory.getLogger(AmpidoAdapter.class);

	@Autowired
	AmpidoAdapterProperties ampidoAdapterProperties;
	
	@Autowired
	MockApiaryCallService apiaryCallService;


	public void getParkingSpaceList() {

	}

	public void getParkingSpaceImage() {

	}

	/**
	 * @param bookingRequest
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 */
	public BookingDetails bookParkingSpace(BookingRequest bookingRequest) throws JsonParseException, JsonMappingException, IOException {
		
		logger.info("Invoking service  bookParkingSpace Slot ID===" + bookingRequest.getSlotId());

/*		Type parkingSlotType01 = new Type();
		parkingSlotType01.setId("1001");
		parkingSlotType01.setName("Garage");

		Feature parkingSlotFeature01 = new Feature();
		parkingSlotFeature01.setId("2001");
		parkingSlotFeature01.setName("EV loading station available");
		List<Feature> parkingFeautures = new ArrayList<Feature>();
		parkingFeautures.add(parkingSlotFeature01);

		ExclusiveFor parkingSlotExclusive01 = new ExclusiveFor();
		ExclusiveFor parkingSlotExclusive02 = new ExclusiveFor();
		parkingSlotExclusive01.setName("Mercedes Benz");
		parkingSlotExclusive02.setName("Smart");
		List<ExclusiveFor> parkingExclusives = new ArrayList<ExclusiveFor>();
		parkingExclusives.add(parkingSlotExclusive01);
		parkingExclusives.add(parkingSlotExclusive02);

		Image parkingSlotImage01 = new Image();
		parkingSlotImage01.setType("Mercesed Benz Parking slots");
		parkingSlotImage01
				.setUrl("http://images.all-free-download.com/images/graphiclarge/daisy_pollen_flower_220533.jpg");
		List<Image> parkingImages = new ArrayList<Image>();
		parkingImages.add(parkingSlotImage01);

		ParkingSlot parkingSlot = new ParkingSlot();
		parkingSlot.setType(parkingSlotType01);
		parkingSlot.setFeatures(parkingFeautures);
		parkingSlot.setExclusiveFor(parkingExclusives);
		parkingSlot.setImages(parkingImages);
		parkingSlot.setUuid("20170004");
		parkingSlot.setFreeUntil("20-06-2017");
		parkingSlot.setPriceFirstHour(1f);
		parkingSlot.setPriceTotal(2f);
		parkingSlot.setLatitude(48.7666667);
		parkingSlot.setLongitude(9.1833333);
		parkingSlot.setAccessMethod("barrier");
		parkingSlot.setAccessRestriction("Euro 6 vehicles only");
		parkingSlot.setImportantInformation("Barrier will be opened only 10 minutes before and after start time");
		parkingSlot.setDescription("It is a private parking lot");
		parkingSlot.setCountry("DEU");
		parkingSlot.setCity("Köln");
		parkingSlot.setPostalCode("50679");
		parkingSlot.setStreetName("Charles-de-Gaulle-Platz");
		parkingSlot.setStreetNumber("1 - 3");

		Barrier barrier01 = new Barrier();
		barrier01.setUuid("2017003");
		barrier01.setPosition("Inlet");
		Barrier barrier02 = new Barrier();
		barrier02.setUuid("2017003");
		barrier02.setPosition("Inlet");

		List<Barrier> barriers = new ArrayList<Barrier>();
		barriers.add(barrier01);
		barriers.add(barrier02);
		
		BookingResponse bookingResponse = new BookingResponse();
		bookingResponse.setCiamId("CIAM-123");
		bookingResponse.setUuid(bookingRequest.getSlotId());
		bookingResponse.setBarriers(barriers);
		bookingResponse.setStartTime(bookingRequest.getStartTime());
		bookingResponse.setEndTime(bookingRequest.getEndTime());
		bookingResponse.setLicenceplate(bookingRequest.getLicencePlate());
		bookingResponse.setParkingSlot(parkingSlot);
		bookingResponse.setStatusCode("200");
		bookingResponse.setStatusMessage("Parking Reservation is done successfully without errors.");*/
		
		BookingDetails bookingResponse = apiaryCallService.getBookingResponse(bookingRequest);
		
		return bookingResponse;

	}

	public void openParkingBarrier(String TransactionId) {

	}

	public void cancelBooking(String TransactionId) {

	}

	/**
	 * Returns the access token used for authorization.
	 *
	 * @param grant
	 *            Type: <String> # To differentiate if it is first time getting
	 *            the access token or refreshing the expired token
	 * @param user
	 *            name: <String> # If first time,provide valid username
	 * @param password:
	 *            <String> # If first time,provide valid password
	 * @param refresh
	 *            token: <INTEGER> # If in case token is expired,pass the
	 *            refresh token value
	 * @param client
	 *            Id: <String> # Client Id
	 * @param client
	 *            secret: <ISO 8601> # client secret value
	 * 
	 * @return AccessTokenResponse
	 * 
	 **/

	// @ApiOperation(value = "Get the access token value for Ampido
	// authorization.")
	// @ApiResponses(value = {
	// @ApiResponse(code = 200, message = "Access Token fetched successfully
	// without errors."),
	// @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
	// @ApiResponse(code = 403, message = "User is not authorized."),
	// @ApiResponse(code = 500, message = "A provider or general error
	// occurred.")
	// })
	// @RequestMapping(value = "/getAccessToken", method = RequestMethod.POST,
	// produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	// @ResponseStatus(HttpStatus.OK)

	public AccessTokenResponse getAccessToken(AccessTokenRequest accessTokenRequest) {

		logger.info("Invoking service  getAccessToken");

		AccessTokenResponse accessTokenResponse = new AccessTokenResponse();

		if (null == accessTokenRequest.getGrantType()) {
			// accessTokenResponse.setErrors(setPayLoadMissingError("Grant
			// Type"));
			return accessTokenResponse;
		} else if (ApplicationContants.GRANT_TYPE_PASSWORD.equalsIgnoreCase(accessTokenRequest.getGrantType())) {

			if (null == accessTokenRequest.getUserName()) {
				// accessTokenResponse.setErrors(setParameterMissingError("User
				// Name"));
				return accessTokenResponse;
			}
			if (null == accessTokenRequest.getPassword()) {
				// accessTokenResponse.setErrors(setParameterMissingError("Password"));
				return accessTokenResponse;
			}

		} else if (ApplicationContants.GRANT_TYPE_REFRESH_TOKEN.equalsIgnoreCase(accessTokenRequest.getGrantType())) {
			if (null == accessTokenRequest.getRefreshToken()) {
				// accessTokenResponse.setErrors(setParameterMissingError("Refresh
				// Token"));
				return accessTokenResponse;
			}
		}

		if (null == accessTokenRequest.getClientID()) {
			// accessTokenResponse.setErrors(setParameterMissingError("Client
			// ID"));
			return accessTokenResponse;
		}
		if (null == accessTokenRequest.getClientSecret()) {
			// accessTokenResponse.setErrors(setParameterMissingError("Client
			// Secret"));
			return accessTokenResponse;
		}
		return accessTokenResponse;

	}

	/***
	 * Receives parking space from ampido and returns modified parkingSpaceList Response
	 * @param latTr
	 * @param longTr
	 * @param latBr
	 * @param longBr
	 * @param startTime
	 * @param endTime
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @return parkingspace list response
	 */
	public ParkingResponse getParkingSpaceList(double latTr, double longTr,
            double latBr, double longBr, String startTime, String endTime) throws JsonParseException, JsonMappingException, IOException {

     ParkingResponse parkingSpaceResponse  = new ParkingResponse();
     

     ParkingRequest parkingRequest = new ParkingRequest();
     
//     System.setProperty("proxyHost", "53.88.72.33");
//     System.setProperty("proxyPort", "3128");
     final String uriParkingSpace = "https://private-9892f-paskingspace.apiary-mock.com/parkingspaces";
     RestTemplate restTemplate = new RestTemplate();
     
     final HttpHeaders headers = new HttpHeaders();
     headers.setContentType(MediaType.APPLICATION_JSON);
     
     HttpEntity<ParkingRequest> entity = new HttpEntity<>(parkingRequest, headers);
     ResponseEntity<String> response = restTemplate.exchange(uriParkingSpace, HttpMethod.GET, entity,
                   String.class);
     
     ObjectMapper mapper = new ObjectMapper();
     parkingSpaceResponse = mapper.readValue(response.getBody(), ParkingResponse.class);
     
     for(int i=0;i<parkingSpaceResponse.getParkingSlots().size();i++)
     {
            parkingSpaceResponse.getParkingSlots().get(i).setStartTime("2017-04-18T11:05:55.312Z");
            parkingSpaceResponse.getParkingSlots().get(i).setFreeUntil("2017-04-18T11:05:55.312Z");
     }
     parkingSpaceResponse.setStatusMessage("Successful");
     parkingSpaceResponse.setStatusCode("200");
     
     return parkingSpaceResponse;
}



}
