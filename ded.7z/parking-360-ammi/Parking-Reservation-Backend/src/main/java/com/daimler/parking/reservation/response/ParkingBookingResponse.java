package com.daimler.parking.reservation.response;

import java.io.Serializable;

public class ParkingBookingResponse extends BaseResponse implements Serializable{
	
	

}
