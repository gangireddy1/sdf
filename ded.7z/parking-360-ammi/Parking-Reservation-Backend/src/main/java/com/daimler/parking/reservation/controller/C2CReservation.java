package com.daimler.parking.reservation.controller;

import com.daimler.parking.reservation.manager.C2CManager;
import com.daimler.parking.reservation.model.ParkingGarageAddress;
import com.daimler.parking.reservation.model.ParkingSlot;
import com.daimler.parking.reservation.request.BookingRequest;
import com.daimler.parking.reservation.request.CancellationRequest;
import com.daimler.parking.reservation.request.EventNotificationRequest;
import com.daimler.parking.reservation.request.ParkingBarrierRequest;
import com.daimler.parking.reservation.request.ParkingExtensionRequest;
import com.daimler.parking.reservation.request.ParkingOffenderRequest;
import com.daimler.parking.reservation.request.ParkingTransactionRequest;
import com.daimler.parking.reservation.request.PaymentRequest;
import com.daimler.parking.reservation.response.BaseResponse;
import com.daimler.parking.reservation.response.BookingDetails;
import com.daimler.parking.reservation.response.EventNotificationResponse;
import com.daimler.parking.reservation.response.ParkingBarrierResponse;
import com.daimler.parking.reservation.response.ParkingBookingResponse;
import com.daimler.parking.reservation.response.ParkingExtensionResponse;
import com.daimler.parking.reservation.response.ParkingOffenderResponse;
import com.daimler.parking.reservation.response.ParkingResponse;
import com.daimler.parking.reservation.response.PaymentResponse;
import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;
import javax.validation.constraints.DecimalMax;
import javax.validation.constraints.DecimalMin;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@Validated
@Api(value = "Search Parking Spaces", description = "Endpint for C2C Parking Reservation")
@RequestMapping(value = "/c2creservation/v1")
public class C2CReservation extends BaseController {

	private static final Logger logger = LoggerFactory.getLogger(C2CReservation.class);

	@Autowired
	private C2CManager c2cmanager;

	/**
	 * Returns all parking Space details on the given latitude, longitude,radius and start time. 
	 *
	 * @param latitude: <DECIMAL> # search location
	 * @param longitude: <DECIMAL> # search location
	 * @param distance: <DECIMAL> # search radius in km. Max: 20km
	 * @param page[number]: <INTEGER> # page number of search result
	 * @param page[size]: <INTEGER> # number of results per page
	 * @param start_time: <ISO 8601> # start time of parking lot booking
	 * @param end_time: <ISO 8601> # (optional) end time of parking lot booking
	 * @param max_results: <Decimal(3)> # (optional) maximum number of parking lots in result, sorted by distance
	 * 
	 * @return    dummy static ViewParkingSpaceResponses as List
	 * @throws IOException 
	 
	**/
	 
	@CrossOrigin
	@ApiOperation(value = "Returns all parking Spaces details for the given latitude, longitude,radius and start time.")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Space search finished successfully without errors"),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.")
	})
	@RequestMapping(value = "/parkingSpaceList", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public ParkingResponse getParkingSpaceList(

		@ApiParam(value = "LatitudeTopLeft, range: -90.0 - 90.0", defaultValue = "48.7666667", required = true)
		@RequestParam(value = "latitudeTopLeft", required = true)
		@DecimalMin(value = "-90.0", message = "latitude must be at least -90.0")
		@DecimalMax(value = "90.0", message = "latitude can only be up to 90.0")
		double latitudeTopLeft,
		
		@ApiParam(value = "LongitudeTopLeft, range: -180.0 - 180.0", defaultValue = "9.1833333", required = true)
		@RequestParam(value = "longitudeTopLeft", required = true)
		@DecimalMin(value = "-180.0", message = "longitude must be at least -180.0")
		@DecimalMax(value = "180.0", message = "longitude can only be up to 180.0")
		double longitudeTopLeft,
		
		@ApiParam(value = "LatitudeBottomRight, range: -90.0 - 90.0", defaultValue = "48.7666667", required = true)
		@RequestParam(value = "latitudeBottomRight", required = true)
		@DecimalMin(value = "-90.0", message = "latitude must be at least -90.0")
		@DecimalMax(value = "90.0", message = "latitude can only be up to 90.0")
		double latitudeBottomRight,
		
		@ApiParam(value = "LongitudeBottomRight, range: -180.0 - 180.0", defaultValue = "9.1833333", required = true)
		@RequestParam(value = "longitudeBottomRight", required = true)
		@DecimalMin(value = "-180.0", message = "longitude must be at least -180.0")
		@DecimalMax(value = "180.0", message = "longitude can only be up to 180.0")
		double longitudeBottomRight,

		@ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-04-18T11:05:55.312Z", required = true, type="ISO 8601 Date")
		@RequestParam(value = "startTime", required = true)
//		@DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
		String startTimeI,
		
		@ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-04-18T12:05:55.312Z", required = false, type="ISO 8601 Date")
		@RequestParam(value = "endTime", required = false)
//		@DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
		String endTimeI
			) throws JsonParseException, JsonMappingException, IOException {

		logger.info("Invoking service  getParkingSpaceList");


		DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ISO_DATE_TIME;
//		LocalDateTime startTime = LocalDateTime.parse(startTimeI,dateTimeFormatter);
//		LocalDateTime endTime = LocalDateTime.parse(endTimeI,dateTimeFormatter);
		
		
		ParkingResponse parkingSpaceResponse  = new ParkingResponse();
		
		parkingSpaceResponse = c2cmanager.getAmpidoAdapter().getParkingSpaceList(latitudeTopLeft,longitudeTopLeft,
				latitudeBottomRight, longitudeBottomRight,startTimeI, endTimeI);

		return parkingSpaceResponse;
	
	}

	/**
	 * Book Parking Space on for a given parking lot identifier
	 * @param bookingRequest
	 * @param servletRequest
	 * @return
	 * @throws JsonParseException
	 * @throws JsonMappingException
	 * @throws IOException
	 * @throws KeyManagementException
	 * @throws NoSuchAlgorithmException
	 * @throws KeyStoreException
	 */
	@ApiOperation(value = "Reserve a Parking Space for selected Parking lot")
	@ApiResponses(value = {
			@ApiResponse(code = 200, message = "Parking Reservation is done successfully without errors."),
			@ApiResponse(code = 400, message = "Parameters are invalid or missing."),
			@ApiResponse(code = 403, message = "User is not authorized."),
			@ApiResponse(code = 500, message = "A provider or general error occurred.") })
	@RequestMapping(value = "/bookParkingSpace", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
	@ResponseStatus(HttpStatus.OK)
	public ParkingBookingResponse bookParkingSpace(
			@ApiParam(value = "Booking Request for Parking Reservation", required = true) @Valid @RequestBody BookingRequest bookingRequest,
			HttpServletRequest servletRequest) throws JsonParseException, JsonMappingException, IOException,
			KeyManagementException, NoSuchAlgorithmException, KeyStoreException {

		BookingDetails bookingResponse = new BookingDetails();

		ParkingBookingResponse parkingBookingResponse = new ParkingBookingResponse();

		logger.info("Inside the booking parking space method");

		if (null == bookingRequest) {
			parkingBookingResponse.setErrors(setPayLoadMissingError("Booking Payload"));
			return parkingBookingResponse;
		}

		if (c2cmanager.getCiamService().isAuthorized(servletRequest))
		{	

		bookingResponse = c2cmanager.getAmpidoAdapter().bookParkingSpace(bookingRequest);

		PaymentRequest paymentRequest = new PaymentRequest();

		paymentRequest.setAccountHolderName("Mr. Sumit Ranjan");
		paymentRequest.setAccountNumber("99999999999999");
		paymentRequest.setExpiresDate("2016-06-24'T'14:13:20.001'Z'");

		PaymentResponse paymentResponse = c2cmanager.getC2CBookingHandler().getPaymentService()
				.addOrder(paymentRequest);

		EventNotificationRequest notificationRequest = new EventNotificationRequest();
		ParkingGarageAddress address = new ParkingGarageAddress();
		address.setBuildingNo("B123");
		address.setCity("Munich");
		address.setCountry("Germany");
		address.setStreet("Munich Street");
		address.setZipcode("560066");
		notificationRequest.setDuration("2hrs");
		notificationRequest.setEndDateTime("06/16/2017");
		notificationRequest.setEventType("local");
		notificationRequest.setFinId("F123");
		notificationRequest.setParkingFacilityName("Munich Facility");
		notificationRequest.setPrice("2$");
		notificationRequest.setStartDateTime("06/14/2017");
		notificationRequest.setUserId("U123");
		notificationRequest.setAddress(address);

		ParkingTransactionRequest parkingTxnReq = new ParkingTransactionRequest();

		parkingTxnReq.setBookingResponse(bookingResponse);

		EventNotificationResponse eventNotificationResponse = c2cmanager.getC2CBookingHandler().getNotificationService()
				.addNotification(notificationRequest);
		parkingTxnReq.setNotificationId(eventNotificationResponse.getNotificationId());

		parkingTxnReq.setTxnID(paymentResponse.getTxnId());
		
		parkingTxnReq.setServiceProvider("AMPIDO");

		logger.info("parkingTxnReq===="+parkingTxnReq.toString());
		
		parkingBookingResponse = c2cmanager.getC2CBookingHandler().getParkingTransactionHistoryService()
				.addParkingTransactionHistory(parkingTxnReq);

		return parkingBookingResponse;
		
		
		}
		else{
			parkingBookingResponse.setErrors(setPayLoadMissingError("CIAM ID is not validated"));
			return parkingBookingResponse;
		}

	}

	/**
     * Returns a parking Space details for the given parking lot.
     *  
     * @param parkingSlotId-unique parking lot identifier
     * @param start_time: <ISO 8601> # start time of parking lot booking
     * @param end_time: <ISO 8601> # (optional) end time of parking lot booking
     * 
     * @return      ViewParkingSpaceResponse 
     
    **/

    @ApiOperation(value = "Show the parking Space details for a given Parking Space")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Parking Space details fetched successfully without errors."),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.")
    })
    @RequestMapping(value ="/parkingSpace", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ParkingSlot viewParkingSpace(
            @ApiParam(value = "Start time of parking lot booking ", defaultValue = "2017-04-18T11:05:55.312Z", required = true)
            @RequestParam(value = "startTime", required = false)
            @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime startTime,
            
            @ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-04-18T12:05:55.312Z", required = false)
            @RequestParam(value = "endTime", required = false)
            @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime endTime,
            
            @ApiParam(value = "Viewing Request for Parking Reservation", required = true)   
            @RequestParam(value = "parkingSlotId", required = true)
            String parkingSlotId) throws JsonProcessingException 
    { 
        
        logger.info("Invoking service  viewParkingSpace with ParkingSlotId ="+parkingSlotId);
        
       
        
        return null;

    }
    
    /**
     * Cancel a  Parking Space on for a given unique rent identifier(bookingId)
     * @param bookingId: <string>, # unique rent identifier
     * @return      Cancellation response.
    **/
    
    @ApiOperation(value = "Cancel the Reservation for a booked Parking Space")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Cancellation done successfully without errors."),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.")
    })
    @RequestMapping(value ="/cancelParkingSpace", method = RequestMethod.DELETE, consumes = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public BaseResponse cancelBooking(
            @Valid @RequestBody CancellationRequest cancellationRequest
            ) throws JsonProcessingException { 
        
        logger.info("Invoking service  cancelBooking with bookingId ="+cancellationRequest.getBookingId());
        logger.info("Invoking service  cancelBooking with cancelReason ="+cancellationRequest.getCancelReason());
        
        
        BaseResponse parkingSpaceBaseResponse = new BaseResponse();
        
        parkingSpaceBaseResponse.setStatusCode("200");
        parkingSpaceBaseResponse.setStatusMessage("Cancellation is done successfully.");
        
        return parkingSpaceBaseResponse;
        
    }
    
    /**
     * Upload parking offender Image 
     * @param picture:: <Base64> # encoded picture
     * @param slotUuid: <string>, # unique parking lot identifier
     * @param description: <String> # description of the incidence
     * @return      201 as status code, if its uploaded successfully.
    **/
    
    
    @ApiOperation(value = "Upload the parking Offender Image")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Parking offender image is uploaded successfully"),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.")
    })
    @RequestMapping(value = "/parkingOffenderImage", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ParkingOffenderResponse uploadParkingOffenderImage(
            @ApiParam(value = "Uploading Parking Offender Image", required = true)  
            @Valid @RequestBody
            ParkingOffenderRequest parkingOffenderRequest) throws JsonProcessingException{
        
        logger.info("Invoking service  uploadParkingOffenderImage");
        ParkingOffenderResponse offenderResponse = new ParkingOffenderResponse();
        
        
        offenderResponse.setMessage("Upload Success");
        offenderResponse.setStatusCode("200");
        offenderResponse.setStatusMessage("Parking offender image is uploaded successfully");
        
        return offenderResponse;

    }
    
    /**
     * Open a  Parking Barrier on for a given unique barrier identifier(barrierUuid)
     * @param barrierUuid: <string>, # unique parking barrier identifier
     * @return      Open Parking Barrier response.
     
    **/
    @ApiOperation(value = "Open the Parking Barrier for a customer")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Parking Barrier is opened successfully"),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.")
    })
    @RequestMapping(value = "/openParkingBarrier", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ParkingBarrierResponse openParkingBarrier(   
        @ApiParam(value = "Parking Barrier Request for Reservation", required = true) 
        @Valid @RequestBody ParkingBarrierRequest parkingBarrierRequest
        ) throws JsonProcessingException { 
    
        
    logger.info("Invoking service  openParkingBarrier with BarrierUuid ="+parkingBarrierRequest.getBarrierUuid());
    
    
    ParkingBarrierResponse parkingBarrierResponse = new ParkingBarrierResponse();
    parkingBarrierResponse.setMessage("barrier with id"+parkingBarrierRequest.getBarrierUuid()+"opened successfully");
    parkingBarrierResponse.setStatusMessage("Parking Barrier is opened successfully");  
    parkingBarrierResponse.setStatusCode("200");
    
    
    return parkingBarrierResponse;
    }
    
    /**
     * Extension request for a booked slot to check if parking extension is possible or not
     * @ @param bookingId: <string>, # unique rent identifier
     * @ @param  end_time: <ISO 8601> # (optional) end time of parking lot booking
     * @return      Response code
     
    **/
    @ApiOperation(value = "Parking Space Extension request for a reserved parking  ")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Opening Barrier done successfully without errors."),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.")
    })
    @RequestMapping(value = "/parkingSpaceExtension", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public ParkingExtensionResponse getParkingSpaceExtension(   
            
            @ApiParam(value = "bookingId", required = true) 
            @RequestParam(value = "bookingId", required = true)
            String bookingId,
            
            @ApiParam(value = "End time of parking lot booking ", defaultValue = "2017-04-18T12:05:55.312Z", required = false)
            @RequestParam(value = "endTime", required = false)
            @DateTimeFormat(iso= DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime endTime
            
        ) throws JsonProcessingException { 
    
        
    logger.info("Invoking service  getParkingSpaceExtension with bookingId ="+bookingId);
    
    
    
    ParkingExtensionResponse ParkingExtensionResponse = new ParkingExtensionResponse();
    
    ParkingExtensionResponse.setStatusCode("200");
    ParkingExtensionResponse.setStatusMessage("OK");
    
    return ParkingExtensionResponse;
    }
    
    
    
    /**
     * Parking Extension Bookingr(bookingUUID)
     * @param bookingId: <string>, # unique rent identifier
     * @return      Booking response.
     
    **/
    @ApiOperation(value = "Parking Extension Booking")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Parking Extension Booking successfully done"),
            @ApiResponse(code = 400, message = "Parameters are invalid or missing."),
            @ApiResponse(code = 403, message = "User is not authorized."),
            @ApiResponse(code = 500, message = "A provider or general error occurred.")
    })
    @RequestMapping(value = "/extensionbooking", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_UTF8_VALUE)
    @ResponseStatus(HttpStatus.OK)
    public BookingDetails extensionbooking(    
        @ApiParam(value = "Parking Barrier Request for Reservation", required = true) 
        @Valid @RequestBody ParkingExtensionRequest parkingExtensionRequest
        ) throws JsonProcessingException { 
    
        
    logger.info("Invoking service  extensionBooking with Booking Id ="+parkingExtensionRequest.getBookingId());
    
    BookingDetails bookingResponse = new BookingDetails();
    
    return bookingResponse;
    
    }
    

}
