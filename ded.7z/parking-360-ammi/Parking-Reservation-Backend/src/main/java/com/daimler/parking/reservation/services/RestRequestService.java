package com.daimler.parking.reservation.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.daimler.parking.reservation.authorization.BasicAuthentication;

import java.net.URI;

/**
 * Wrapper class for RestTemplate Requests with basic authentication and header support.
 */
@Component
public class RestRequestService {

    private RestTemplate restTemplate;

/*    @Autowired
    public RestRequestService(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }*/
    
	 @Bean
	    public RestTemplate template(){
	        return new RestTemplate();
	    }

    /**
     * Executes a HTTP GET using RestTemplate to the given url responding a ResponseEntity of the given entity class.
     *
     * @param uri           Url to call
     * @param type          response entity type
     * @param basicAuthData optional basic Authentication data
     * @param <T>           Type of response entity
     * @param headers       additional headers
     * @return ResponseEntity of the given type.
     */
    public <T> ResponseEntity<T> get(URI uri, Class<T> type, BasicAuthentication basicAuthData, HttpHeaders headers) {

        if(headers == null) {
            headers = new HttpHeaders();
        }

        if (basicAuthData != null && basicAuthData.isEnabled()) {
            headers.add("Authorization", "Basic " + basicAuthData.getBase64BasicAuthString());
        }

        HttpEntity<String> req = new HttpEntity<>(headers);
        return restTemplate.exchange(uri, HttpMethod.GET, req, type);
    }
}
