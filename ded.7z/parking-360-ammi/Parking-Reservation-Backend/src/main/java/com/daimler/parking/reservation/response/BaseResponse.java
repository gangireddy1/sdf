package com.daimler.parking.reservation.response;

import java.util.List;

import com.daimler.parking.reservation.exceptions.handler.data.ErrorObject;

public class BaseResponse {

	private String statusMessage;

	private String statusCode;

	private List<ErrorObject> errors;
	
	public String getStatusMessage() {
		return statusMessage;
	}

	public void setStatusMessage(String statusMessage) {
		this.statusMessage = statusMessage;
	}

	public String getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(String statusCode) {
		this.statusCode = statusCode;
	}

	public List<ErrorObject> getErrors() {
		return errors;
	}

	public void setErrors(List<ErrorObject> errors) {
		this.errors = errors;
	}
	
	

}
