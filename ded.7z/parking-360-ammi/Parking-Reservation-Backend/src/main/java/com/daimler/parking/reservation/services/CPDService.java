package com.daimler.parking.reservation.services;

import org.springframework.stereotype.Component;

@Component
public class CPDService {

}
