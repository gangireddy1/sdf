package com.daimler.parking.reservation.authorization;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.daimler.parking.reservation.authorization.AuthorizationAdapter;
import com.daimler.parking.reservation.exceptions.AuthorizationException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Component
public class AuthorizationInterceptor extends HandlerInterceptorAdapter {

    @Autowired
    private AuthorizationAdapter authorizationAdapter;

    private static final Logger logger = LoggerFactory.getLogger(AuthorizationInterceptor.class);

    /**
     *  Interceptor to make sure only authorized user can call the rest API.
     */
    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        logger.debug("Authorization check enter");
        try {
            boolean isAuthorized = authorizationAdapter.isAuthorized(request);
            if (!isAuthorized) {
                throw new AuthorizationException();
            }
            return true;
        } finally {
            logger.debug("Authorization check exit");
        }
    }
}
