package com.daimler.parking.reservation.services;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.client.HttpClientErrorException;

@Component
public class CIAMService {
	
	public boolean isAuthorized(HttpServletRequest request) throws HttpClientErrorException {
		
		
	return true;
		
	}
	

}
