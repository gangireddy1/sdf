package com.daimler.parking.reservation.authorization;

import java.net.URI;
import java.util.Iterator;

import javax.servlet.Filter;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;
import org.springframework.web.util.UriComponentsBuilder;

import com.daimler.parking.reservation.ParkingSpaceBackendApplication;
import com.daimler.parking.reservation.exceptions.MissingRequestHeaderParameterException;
import com.daimler.parking.reservation.services.RestRequestService;
import com.fasterxml.jackson.databind.JsonNode;

@Component
public class AuthorizationAdapter extends AbstractAnnotationConfigDispatcherServletInitializer{

    private AuthorizationProperties authorizationProperties;
    private RestRequestService restRequestService;

    private static final Logger logger = LoggerFactory.getLogger(AuthorizationAdapter.class);

    private static final String MISSING_HEADER_MESSAGE = "%s header is required.";
    private static final String EMPTY_HEADER_MESSAGE = "Required Header parameters must not be empty: %s";
    private static final String LOG_MESSAGE_CPD_CALLED = "Application CPD called, uri: {} ";
    private static final String LOG_MESSAGE_CPD_RETURN = "Application CPD returned, status-code: {}";
    private static final String VHP_ENV_HEADER = "VHP_ENV";

    @Autowired
    public AuthorizationAdapter(RestRequestService restRequestService, AuthorizationProperties authorizationProperties) {
        this.restRequestService = restRequestService;
        this.authorizationProperties = authorizationProperties;
    }

    /**
     * Extracts the Ciam User ID from the HttpServletRequest
     * or throws an MissingRequestHeaderParameterException if ciam can't be extracted.
     *
     * @param request
     * @return ciamUserId
     * @throws MissingRequestHeaderParameterException
     */
    public String getCiamOrThrow(HttpServletRequest request) throws MissingRequestHeaderParameterException {
        String ciamHeader = request.getHeader(authorizationProperties.getCiamHeaderName());

        if (ciamHeader == null) {
            throw new MissingRequestHeaderParameterException(MISSING_HEADER_MESSAGE, authorizationProperties.getCiamHeaderName());
        }
        String ciam = extractCiam(ciamHeader);

        if (StringUtils.isEmpty(ciam)) {
            throw new MissingRequestHeaderParameterException(EMPTY_HEADER_MESSAGE, authorizationProperties.getCiamHeaderName());
        }

        return ciam;
    }

    /**
     * Extracts the vin from the HttpServletRequest
     * or throws an MissingRequestHeaderParameterException if vin can't be extracted.
     *
     * @param request
     * @return vin or MissingRequestHeaderParameterException
     * @throws MissingRequestHeaderParameterException
     */
    private String getVinOrThrow(HttpServletRequest request) throws MissingRequestHeaderParameterException {
        String vin = request.getHeader(authorizationProperties.getVinHeaderName());

        if (vin == null) {
            throw new MissingRequestHeaderParameterException(MISSING_HEADER_MESSAGE, authorizationProperties.getVinHeaderName());
        }

        if (StringUtils.isEmpty(vin)) {
            throw new MissingRequestHeaderParameterException(EMPTY_HEADER_MESSAGE, authorizationProperties.getVinHeaderName());
        }
        return vin;
    }

    /**
     * Checks if user is authorized. Calls CPD to get user information.
     * Returns true if user is authorized or if the authorization isn't enabled.
     *
     * @param request
     * @return true if user is authorized else otherwise.
     * @throws HttpClientErrorException
     */
    public boolean isAuthorized(HttpServletRequest request) throws HttpClientErrorException {
        if (!authorizationProperties.isEnabled()) {
            return true;
        } else {
            try {
                String vin = getVinOrThrow(request);
                String ciam = getCiamOrThrow(request);

                UriComponentsBuilder uriBuilder = UriComponentsBuilder.fromHttpUrl(authorizationProperties.getBaseUrl())
                        .pathSegment("vehicles", vin)
                        .pathSegment("users", ciam)
                        .pathSegment("serviceinformations");

                URI uri = uriBuilder.build().encode().toUri();

                logger.info(LOG_MESSAGE_CPD_CALLED, uri);

                final HttpHeaders headers = new HttpHeaders();
                headers.add(VHP_ENV_HEADER, authorizationProperties.getVhpEnv());
                ResponseEntity<JsonNode> response = restRequestService
                        .get(uri, JsonNode.class, authorizationProperties.getBasicAuth(), headers);

                logger.info(LOG_MESSAGE_CPD_RETURN, response.getStatusCode());

                return checkAuthorization(response.getBody());
            } catch (HttpClientErrorException e) {
                logger.warn(LOG_MESSAGE_CPD_RETURN, e.getStatusCode());
                throw e;
            }
        }
    }


    /**
     * Returns true if user is authorized.
     *
     * @param jsonNode
     * @return
     */
    private boolean checkAuthorization(JsonNode jsonNode) {

        boolean isAuthorized = false;

        try {
            Iterator<JsonNode> userIterator = jsonNode.elements();
            while (userIterator.hasNext()) {
                JsonNode service = userIterator.next();

                for (int serviceId : authorizationProperties.getServiceIds()) {
                    if (service.get("serviceIdAsInt").asInt() == serviceId) {
                        isAuthorized = isAuthorized || service.get("serviceActive").asBoolean();
                    }
                }
            }
        } catch (NullPointerException e) {
            logger.error("Couldn't parse response from CPD. Response: {}", jsonNode);
        }
        return isAuthorized;
    }

    /**
     * Format: 'uid=000d09029474cc83,ou=endconsumers,ou=people,o=iapdir' or  '000d09029474cc83'
     *
     * @param smHeader
     * @return
     */
    private String extractCiam(String smHeader) {
        String uid = "uid=";
        if (smHeader.contains(uid)) {
            return smHeader.split(uid)[1].split(",")[0];
        } else {
            return smHeader;
        }
    }
    
    @Override
    protected Filter[] getServletFilters() {
        return new Filter[]{ new CORSFilter()};
    }

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		 return new Class[] { ParkingSpaceBackendApplication.class };
	}

	@Override
	protected String[] getServletMappings() {
		return new String[] { "/" };
	}

}
