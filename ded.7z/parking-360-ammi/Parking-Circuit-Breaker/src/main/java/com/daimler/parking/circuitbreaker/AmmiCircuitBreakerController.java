package com.daimler.parking.circuitbreaker;
//package com.daimler.ammi.circuitbreaker;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Controller;
//import org.springframework.web.bind.annotation.RequestMapping;
//
//@Controller
//public class AmmiCircuitBreakerController {
//    @Autowired
//    private AmmiCircuitBreakerService ammiCircuitBreakerService;
//
//    @RequestMapping("/ammi/v1/getParkingSpaceList")
//    public String getParkingSpaceList() {
//    	return  ammiCircuitBreakerService.getParkingSpaceList();
//    }
//}
